package com.example

import com.example.data.LedgerJsonCodec
import com.example.data.LedgerRow
import com.example.data.SocialLinks
import com.example.data.TOTAL_LEDGER_ROWS
import com.example.data.calculateLedgerTotals
import com.example.data.defaultFortyRows
import com.example.util.BengaliFormatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun defaultSheet_hasExactlyFortyRows_numbered01To40() {
    val rows = defaultFortyRows()
    assertEquals(40, TOTAL_LEDGER_ROWS)
    assertEquals(40, rows.size)
    assertEquals("০১", BengaliFormatters.formatSerial(rows.first().serial))
    assertEquals("৪০", BengaliFormatters.formatSerial(rows.last().serial))
  }

  @Test
  fun calculateTotals_converts1000GramsTo1Kg_andSupportsBengaliAndEnglishDigits() {
    val rows =
      defaultFortyRows().map { row ->
        when (row.serial) {
          1 -> row.copy(pieces = "১০", kg = "২", gram = "৬৫০", shopName = "রহিম স্টোর")
          2 -> row.copy(pieces = "5", kg = "3", gram = "750", shopName = "করিম এন্টারপ্রাইজ")
          40 -> row.copy(pieces = "২", kg = "০", gram = "৬০০", shopName = "মদিনা ট্রেডার্স")
          else -> row
        }
      }

    val totals = calculateLedgerTotals(rows)
    assertEquals(17L, totals.totalPieces)
    assertEquals(7L, totals.finalKg)
    assertEquals(0L, totals.remainingGram)
    assertEquals(3, totals.filledRowCount)
    assertEquals("৭ কেজি ০ গ্রাম", totals.combinedWeightText)
    assertEquals("৭.০০০ কেজি", totals.decimalWeightText)
  }

  @Test
  fun normalizeFortyRows_alwaysPreserves40RowsInOrder() {
    val partial = listOf(LedgerRow(serial = 5, pieces = "৩", kg = "১", gram = "২৫০", shopName = "টেস্ট দোকান"))
    val normalized = LedgerJsonCodec.normalizeFortyRows(partial)
    assertEquals(40, normalized.size)
    assertEquals("৩", normalized[4].pieces)
    assertEquals("টেস্ট দোকান", normalized[4].shopName)
    assertTrue(normalized[0].isEmpty)
  }

  @Test
  fun permanentSocialLinks_matchExactRequiredUrls() {
    assertEquals("https://www.tiktok.com/@a.f.arif4.0", SocialLinks.TIKTOK_URL)
    assertEquals("https://t.me/Premium_apk782", SocialLinks.TELEGRAM_URL)
    assertEquals("https://www.facebook.com/share/1JrJASgJxJ/", SocialLinks.FACEBOOK_URL)
  }
}
