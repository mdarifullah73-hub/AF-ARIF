package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LedgerRecordEntity
import com.example.ui.components.bouncePressEffect
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBluePrimary
import com.example.util.BengaliFormatters

@Composable
fun HistoryScreen(
  records: List<LedgerRecordEntity>,
  onEditRecord: (LedgerRecordEntity) -> Unit,
  onSharePdfRecord: (LedgerRecordEntity) -> Unit,
  onPrintRecord: (LedgerRecordEntity) -> Unit,
  onDeleteRecord: (LedgerRecordEntity) -> Unit,
  onGoToCalculator: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 760.dp).padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      // Header Banner
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(RoyalBluePrimary, RoyalBlueBright)))
            .padding(horizontal = 16.dp, vertical = 14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "সংরক্ষিত হিসাব খাতা",
              style = MaterialTheme.typography.titleLarge,
              color = Color.White,
            )
            Text(
              text = "মোট সংরক্ষিত হিসাব: ${BengaliFormatters.toBengaliDigits(records.size)}টি",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFFDCEBFF),
            )
          }
          Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.2f)) {
            Text(
              text = BengaliFormatters.toBengaliDigits(records.size),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      if (records.isEmpty()) {
        EmptyLedgerState(
          title = "এখনও কোনো হিসাব সংরক্ষিত নেই",
          subtitle = "হিসাব ফরমে পিস, কেজি, গ্রাম ও দোকানের নাম লিখে সংরক্ষণ বাটনে চাপ দিলে এখানে তালিকা দেখাবে।",
          actionLabel = "হিসাব ফরমে যান",
          onAction = onGoToCalculator,
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize().testTag("history_records_list"),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 16.dp),
        ) {
          items(records, key = { it.id }) { record ->
            SavedLedgerCard(
              record = record,
              onEdit = { onEditRecord(record) },
              onSharePdf = { onSharePdfRecord(record) },
              onPrint = { onPrintRecord(record) },
              onDelete = { onDeleteRecord(record) },
            )
          }
        }
      }
    }
  }
}

@Composable
fun SavedLedgerCard(
  record: LedgerRecordEntity,
  onEdit: () -> Unit,
  onSharePdf: () -> Unit,
  onPrint: () -> Unit,
  onDelete: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth().testTag("saved_record_card_${record.id}"),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.CalendarMonth,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
              )
              Spacer(Modifier.width(5.dp))
              Text(
                text = BengaliFormatters.formatDateLongBengali(record.dateMillis),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
          Spacer(Modifier.width(8.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
          ) {
            Text(
              text = "নং: ${record.memoNo}",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
          }
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("delete_record_${record.id}"),
        ) {
          Icon(
            imageVector = Icons.Rounded.DeleteOutline,
            contentDescription = "হিসাব মুছুন",
            tint = MaterialTheme.colorScheme.error,
          )
        }
      }

      if (record.partyName.isNotBlank()) {
        Spacer(Modifier.height(6.dp))
        Text(
          text = "নাম: ${record.partyName}",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      if (record.shopNamesIndex.isNotBlank()) {
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Rounded.Storefront,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(15.dp),
          )
          Spacer(Modifier.width(5.dp))
          Text(
            text = record.shopNamesIndex,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Spacer(Modifier.height(10.dp))

      // Totals Summary Pills
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RecordStatPill(
          label = "পিস",
          value = BengaliFormatters.toBengaliDigits(record.totalPieces),
          modifier = Modifier.weight(1f),
        )
        RecordStatPill(
          label = "সম্মিলিত ওজন",
          value = BengaliFormatters.formatCombinedWeight(record.finalKg, record.remainingGram),
          modifier = Modifier.weight(2f),
        )
      }

      Spacer(Modifier.height(10.dp))

      // Action Buttons Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val editInteraction = remember { MutableInteractionSource() }
        FilledTonalButton(
          onClick = onEdit,
          interactionSource = editInteraction,
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
          modifier = Modifier.weight(1.2f).height(44.dp).bouncePressEffect(editInteraction).testTag("edit_record_${record.id}"),
        ) {
          Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(Modifier.width(5.dp))
          Text("সম্পাদনা", style = MaterialTheme.typography.labelMedium)
        }

        val pdfInteraction = remember { MutableInteractionSource() }
        OutlinedButton(
          onClick = onSharePdf,
          interactionSource = pdfInteraction,
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
          modifier = Modifier.weight(1f).height(44.dp).bouncePressEffect(pdfInteraction).testTag("pdf_record_${record.id}"),
        ) {
          Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(Modifier.width(4.dp))
          Text("PDF", style = MaterialTheme.typography.labelMedium)
        }

        val printInteraction = remember { MutableInteractionSource() }
        OutlinedButton(
          onClick = onPrint,
          interactionSource = printInteraction,
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
          modifier = Modifier.weight(1f).height(44.dp).bouncePressEffect(printInteraction).testTag("print_record_${record.id}"),
        ) {
          Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(Modifier.width(4.dp))
          Text("প্রিন্ট", style = MaterialTheme.typography.labelMedium)
        }
      }
    }
  }
}

@Composable
private fun RecordStatPill(label: String, value: String, modifier: Modifier = Modifier) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
    modifier = modifier,
  ) {
    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun EmptyLedgerState(
  title: String,
  subtitle: String,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
) {
  Box(
    modifier = Modifier.fillMaxSize().padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Box(
        modifier =
          Modifier.size(84.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.FolderOpen,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(42.dp),
        )
      }
      Spacer(Modifier.height(16.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
      if (actionLabel != null && onAction != null) {
        Spacer(Modifier.height(18.dp))
        Button(
          onClick = onAction,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.height(48.dp).testTag("empty_state_action_button"),
        ) {
          Text(actionLabel)
        }
      }
    }
  }
}
