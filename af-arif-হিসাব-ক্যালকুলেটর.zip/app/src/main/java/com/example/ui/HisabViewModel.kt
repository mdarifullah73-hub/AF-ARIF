package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ActiveLedgerSheet
import com.example.data.LedgerJsonCodec
import com.example.data.LedgerRepository
import com.example.data.LedgerRow
import com.example.data.LedgerTotals
import com.example.data.ThemeMode
import com.example.data.calculateLedgerTotals
import com.example.data.defaultFortyRows
import com.example.data.local.AppDatabase
import com.example.data.local.LedgerRecordEntity
import com.example.data.local.SettingsPreferences
import com.example.export.PdfAndPrintManager
import com.example.util.BengaliFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppDestination(val route: String, val labelBengali: String) {
  CALCULATOR("calculator", "হিসাব ফরম"),
  HISTORY("history", "সংরক্ষিত"),
  SEARCH("search", "খুঁজুন"),
  SETTINGS("settings", "সেটিংস"),
}

data class HisabUiState(
  val showWelcomeScreen: Boolean = true,
  val isLoading: Boolean = false,
  val loadingMessage: String = "অপেক্ষা করুন...",
  val showSaveSuccessPopup: Boolean = false,
  val saveSuccessTitle: String = "সংরক্ষণ সফল হয়েছে!",
  val saveSuccessSubtitle: String = "",
  val deleteConfirmRecord: LedgerRecordEntity? = null,
  val showDeleteAllConfirm: Boolean = false,
  val statusBannerMessage: String? = null,
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class HisabViewModel(application: Application) : AndroidViewModel(application) {
  private val db = AppDatabase.getInstance(application)
  private val repository = LedgerRepository(db.ledgerDao())
  private val preferences = SettingsPreferences(application)

  private val _activeSheet = MutableStateFlow(ActiveLedgerSheet())
  val activeSheet: StateFlow<ActiveLedgerSheet> = _activeSheet.asStateFlow()

  val totals: StateFlow<LedgerTotals> =
    _activeSheet
      .map { sheet -> calculateLedgerTotals(sheet.rows) }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LedgerTotals(),
      )

  val themeMode: StateFlow<ThemeMode> =
    preferences.themeModeFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = ThemeMode.LIGHT,
    )

  val savedRecords: StateFlow<List<LedgerRecordEntity>> =
    repository.allRecords.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _searchDateMillis = MutableStateFlow<Long?>(null)
  val searchDateMillis: StateFlow<Long?> = _searchDateMillis.asStateFlow()

  val searchResults: StateFlow<List<LedgerRecordEntity>> =
    combine(_searchQuery, _searchDateMillis) { q, dateMs -> q to dateMs }
      .flatMapLatest { (q, dateMs) ->
        repository.searchRecords(q).map { list ->
          if (dateMs == null) {
            list
          } else {
            val targetIso = BengaliFormatters.formatDateIso(dateMs)
            list.filter { it.dateIso == targetIso }
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  private val _uiState = MutableStateFlow(HisabUiState())
  val uiState: StateFlow<HisabUiState> = _uiState.asStateFlow()

  private var draftRestored = false

  init {
    viewModelScope.launch {
      // Restore active unsaved draft on startup so data survives app close
      val draft = preferences.draftSheetFlow.first()
      if (draft != null) {
        _activeSheet.value = draft
      } else {
        val count = withContext(Dispatchers.IO) { repository.getAllSnapshot().size }
        _activeSheet.update { it.copy(memoNo = BengaliFormatters.formatSerial((count + 1).coerceAtMost(99))) }
      }
      draftRestored = true

      // Smooth welcome splash timing
      delay(1250L)
      _uiState.update { it.copy(showWelcomeScreen = false) }
    }

    // Auto-save active draft smoothly in background
    viewModelScope.launch {
      _activeSheet.debounce(350L).collect { sheet ->
        if (draftRestored) {
          preferences.saveDraft(sheet)
        }
      }
    }
  }

  fun dismissWelcomeImmediately() {
    _uiState.update { it.copy(showWelcomeScreen = false) }
  }

  fun updateMemoNo(memoNo: String) {
    _activeSheet.update { it.copy(memoNo = memoNo) }
  }

  fun updateDateMillis(dateMillis: Long) {
    _activeSheet.update { it.copy(dateMillis = dateMillis) }
  }

  fun updatePartyName(partyName: String) {
    _activeSheet.update { it.copy(partyName = partyName) }
  }

  fun updateRow(
    serial: Int,
    pieces: String? = null,
    kg: String? = null,
    gram: String? = null,
    shopName: String? = null,
  ) {
    _activeSheet.update { current ->
      val updatedRows =
        current.rows.map { row ->
          if (row.serial == serial) {
            row.copy(
              pieces = pieces?.let { BengaliFormatters.filterNumericInput(it) } ?: row.pieces,
              kg = kg?.let { BengaliFormatters.filterNumericInput(it) } ?: row.kg,
              gram = gram?.let { BengaliFormatters.filterNumericInput(it) } ?: row.gram,
              shopName = shopName ?: row.shopName,
            )
          } else {
            row
          }
        }
      current.copy(rows = updatedRows)
    }
  }

  fun clearRow(serial: Int) {
    _activeSheet.update { current ->
      val updatedRows =
        current.rows.map { row ->
          if (row.serial == serial) LedgerRow(serial = serial) else row
        }
      current.copy(rows = updatedRows)
    }
  }

  fun startNewSheet() {
    viewModelScope.launch {
      val nextMemo =
        withContext(Dispatchers.IO) {
          BengaliFormatters.formatSerial((repository.getAllSnapshot().size + 1).coerceAtMost(99))
        }
      _activeSheet.value =
        ActiveLedgerSheet(
          editingRecordId = null,
          memoNo = nextMemo,
          dateMillis = System.currentTimeMillis(),
          partyName = "",
          rows = defaultFortyRows(),
        )
      preferences.saveDraft(_activeSheet.value)
      showBanner("নতুন ৪০ সারির হিসাব ফরম তৈরি করা হয়েছে")
    }
  }

  fun saveCurrentSheet() {
    viewModelScope.launch {
      val sheet = _activeSheet.value
      val currentTotals = calculateLedgerTotals(sheet.rows)
      val wasEditing = sheet.editingRecordId != null

      _uiState.update { it.copy(isLoading = true, loadingMessage = "হিসাব সংরক্ষণ হচ্ছে...") }
      val savedId = withContext(Dispatchers.IO) { repository.saveSheet(sheet) }
      _activeSheet.update { it.copy(editingRecordId = savedId) }
      preferences.saveDraft(_activeSheet.value)

      val subtitle =
        "তারিখ: ${BengaliFormatters.formatDateDisplay(sheet.dateMillis)} • " +
          "${BengaliFormatters.toBengaliDigits(currentTotals.totalPieces)} পিস • " +
          currentTotals.combinedWeightText

      _uiState.update {
        it.copy(
          isLoading = false,
          showSaveSuccessPopup = true,
          saveSuccessTitle = if (wasEditing) "হিসাব হালনাগাদ হয়েছে!" else "হিসাব সংরক্ষিত হয়েছে!",
          saveSuccessSubtitle = subtitle,
        )
      }
    }
  }

  fun dismissSaveSuccessPopup() {
    _uiState.update { it.copy(showSaveSuccessPopup = false) }
  }

  fun loadRecordForEdit(record: LedgerRecordEntity, onLoaded: () -> Unit) {
    _activeSheet.value =
      ActiveLedgerSheet(
        editingRecordId = record.id,
        memoNo = record.memoNo,
        dateMillis = record.dateMillis,
        partyName = record.partyName,
        rows = LedgerJsonCodec.decodeRows(record.rowsJson),
      )
    viewModelScope.launch { preferences.saveDraft(_activeSheet.value) }
    showBanner("সম্পাদনার জন্য খোলা হয়েছে: ${record.dateDisplay}")
    onLoaded()
  }

  fun requestDeleteRecord(record: LedgerRecordEntity) {
    _uiState.update { it.copy(deleteConfirmRecord = record) }
  }

  fun cancelDeleteRecord() {
    _uiState.update { it.copy(deleteConfirmRecord = null) }
  }

  fun confirmDeleteRecord() {
    val target = _uiState.value.deleteConfirmRecord ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(deleteConfirmRecord = null, isLoading = true, loadingMessage = "হিসাব মুছে ফেলা হচ্ছে...") }
      withContext(Dispatchers.IO) { repository.deleteRecord(target.id) }
      if (_activeSheet.value.editingRecordId == target.id) {
        _activeSheet.update { it.copy(editingRecordId = null) }
      }
      _uiState.update { it.copy(isLoading = false) }
      showBanner("হিসাব সফলভাবে মুছে ফেলা হয়েছে")
    }
  }

  fun requestDeleteAll() {
    _uiState.update { it.copy(showDeleteAllConfirm = true) }
  }

  fun cancelDeleteAll() {
    _uiState.update { it.copy(showDeleteAllConfirm = false) }
  }

  fun confirmDeleteAll() {
    viewModelScope.launch {
      _uiState.update { it.copy(showDeleteAllConfirm = false, isLoading = true, loadingMessage = "সকল হিসাব মুছে ফেলা হচ্ছে...") }
      withContext(Dispatchers.IO) { repository.deleteAll() }
      _activeSheet.update { it.copy(editingRecordId = null) }
      _uiState.update { it.copy(isLoading = false) }
      showBanner("সকল সংরক্ষিত হিসাব মুছে ফেলা হয়েছে")
    }
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun updateSearchDateFilter(dateMillis: Long?) {
    _searchDateMillis.value = dateMillis
  }

  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch { preferences.setThemeMode(mode) }
  }

  fun writePdfToUri(context: Context, uri: Uri, sheet: ActiveLedgerSheet = _activeSheet.value) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "PDF তৈরি হচ্ছে...") }
      val result = withContext(Dispatchers.IO) { PdfAndPrintManager.writePdfToUri(context, uri, sheet) }
      _uiState.update { it.copy(isLoading = false) }
      if (result.isSuccess) {
        showBanner("PDF সফলভাবে সংরক্ষণ করা হয়েছে")
      } else {
        showBanner("PDF সংরক্ষণ ব্যর্থ হয়েছে")
      }
    }
  }

  fun sharePdf(context: Context, sheet: ActiveLedgerSheet = _activeSheet.value) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "PDF প্রস্তুত হচ্ছে...") }
      val result = withContext(Dispatchers.IO) { PdfAndPrintManager.createTempPdfAndShare(context, sheet) }
      _uiState.update { it.copy(isLoading = false) }
      result
        .onSuccess { intent ->
          context.startActivity(Intent.createChooser(intent, "PDF শেয়ার বা সংরক্ষণ করুন"))
        }
        .onFailure { showBanner("PDF শেয়ার করা যায়নি") }
    }
  }

  fun printLedger(context: Context, sheet: ActiveLedgerSheet = _activeSheet.value) {
    PdfAndPrintManager.printLedger(context, sheet)
  }

  fun exportBackupToUri(context: Context, uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "ব্যাকআপ ফাইল তৈরি হচ্ছে...") }
      val result =
        withContext(Dispatchers.IO) {
          runCatching {
            val all = repository.getAllSnapshot()
            val json = LedgerJsonCodec.encodeBackup(all)
            context.contentResolver.openOutputStream(uri)?.use { out ->
              out.write(json.toByteArray(Charsets.UTF_8))
            } ?: error("ফাইল লেখা যায়নি")
            all.size
          }
        }
      _uiState.update { it.copy(isLoading = false) }
      result
        .onSuccess { count ->
          showBanner("${BengaliFormatters.toBengaliDigits(count)}টি হিসাবের ব্যাকআপ সংরক্ষিত হয়েছে")
        }
        .onFailure { showBanner("ব্যাকআপ সংরক্ষণে সমস্যা হয়েছে") }
    }
  }

  fun restoreBackupFromUri(context: Context, uri: Uri, replaceExisting: Boolean = false) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "ডেটা রিস্টোর হচ্ছে...") }
      val result =
        withContext(Dispatchers.IO) {
          runCatching {
            val json =
              context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                it.readText()
              } ?: error("ফাইল পড়া যায়নি")
            val parsed = LedgerJsonCodec.decodeBackup(json).getOrThrow()
            repository.restoreBackupRecords(parsed, replaceExisting)
            parsed.size
          }
        }
      _uiState.update { it.copy(isLoading = false) }
      result
        .onSuccess { count ->
          _uiState.update {
            it.copy(
              showSaveSuccessPopup = true,
              saveSuccessTitle = "রিস্টোর সফল হয়েছে!",
              saveSuccessSubtitle = "${BengaliFormatters.toBengaliDigits(count)}টি হিসাব সফলভাবে যুক্ত হয়েছে",
            )
          }
        }
        .onFailure { showBanner("সঠিক ব্যাকআপ ফাইল নির্বাচন করুন") }
    }
  }

  fun exportCsvToUri(context: Context, uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "হিসাব এক্সপোর্ট হচ্ছে...") }
      val result =
        withContext(Dispatchers.IO) {
          runCatching {
            val all = repository.getAllSnapshot()
            val csv = LedgerJsonCodec.encodeRecordsToCsv(all)
            context.contentResolver.openOutputStream(uri)?.use { out ->
              out.write(csv.toByteArray(Charsets.UTF_8))
            } ?: error("CSV লেখা যায়নি")
            all.size
          }
        }
      _uiState.update { it.copy(isLoading = false) }
      result
        .onSuccess { count ->
          showBanner("${BengaliFormatters.toBengaliDigits(count)}টি হিসাব CSV আকারে এক্সপোর্ট হয়েছে")
        }
        .onFailure { showBanner("হিসাব এক্সপোর্ট করা যায়নি") }
    }
  }

  fun shareAllCsv(context: Context) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, loadingMessage = "CSV প্রস্তুত হচ্ছে...") }
      val result =
        withContext(Dispatchers.IO) {
          val all = repository.getAllSnapshot()
          val csv = LedgerJsonCodec.encodeRecordsToCsv(all)
          PdfAndPrintManager.createTempCsvAndShare(context, csv)
        }
      _uiState.update { it.copy(isLoading = false) }
      result
        .onSuccess { intent -> context.startActivity(Intent.createChooser(intent, "হিসাব এক্সপোর্ট শেয়ার")) }
        .onFailure { showBanner("এক্সপোর্ট শেয়ার করা যায়নি") }
    }
  }

  fun clearBanner() {
    _uiState.update { it.copy(statusBannerMessage = null) }
  }

  private fun showBanner(message: String) {
    _uiState.update { it.copy(statusBannerMessage = message) }
  }
}
