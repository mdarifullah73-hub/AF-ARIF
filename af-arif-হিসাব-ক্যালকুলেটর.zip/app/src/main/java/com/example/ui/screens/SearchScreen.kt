package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.LedgerRecordEntity
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBluePrimary
import com.example.util.BengaliFormatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
  query: String,
  selectedDateMillis: Long?,
  results: List<LedgerRecordEntity>,
  onQueryChange: (String) -> Unit,
  onDateFilterChange: (Long?) -> Unit,
  onEditRecord: (LedgerRecordEntity) -> Unit,
  onSharePdfRecord: (LedgerRecordEntity) -> Unit,
  onPrintRecord: (LedgerRecordEntity) -> Unit,
  onDeleteRecord: (LedgerRecordEntity) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showDatePicker by remember { mutableStateOf(false) }

  if (showDatePicker) {
    val pickerState =
      rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis ?: System.currentTimeMillis())
    DatePickerDialog(
      onDismissRequest = { showDatePicker = false },
      confirmButton = {
        TextButton(
          onClick = {
            onDateFilterChange(pickerState.selectedDateMillis)
            showDatePicker = false
          },
          modifier = Modifier.testTag("search_date_confirm"),
        ) {
          Text("ফিল্টার করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDatePicker = false }) { Text("বাতিল") }
      },
    ) {
      DatePicker(state = pickerState)
    }
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 760.dp).padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(RoyalBluePrimary, RoyalBlueBright)))
            .padding(horizontal = 16.dp, vertical = 14.dp),
      ) {
        Column {
          Text(
            text = "পুরোনো হিসাব খুঁজুন",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
          )
          Text(
            text = "দোকানের নাম, তারিখ বা মেমো নং দিয়ে তাৎক্ষণিক খুঁজুন",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFDCEBFF),
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "খুঁজুন") },
        trailingIcon = {
          if (query.isNotEmpty()) {
            IconButton(onClick = { onQueryChange("") }, modifier = Modifier.testTag("clear_search_query")) {
              Icon(Icons.Rounded.Close, contentDescription = "মুছুন")
            }
          }
        },
        placeholder = { Text("দোকানের নাম, গ্রাহকের নাম বা তারিখ লিখুন...") },
        modifier = Modifier.fillMaxWidth().testTag("search_query_input"),
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        FilterChip(
          selected = selectedDateMillis != null,
          onClick = { showDatePicker = true },
          leadingIcon = {
            Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
          },
          label = {
            Text(
              text =
                if (selectedDateMillis != null) {
                  "তারিখ: ${BengaliFormatters.formatDateDisplay(selectedDateMillis)}"
                } else {
                  "তারিখ দিয়ে খুঁজুন"
                }
            )
          },
          modifier = Modifier.testTag("search_date_filter_chip"),
        )

        if (selectedDateMillis != null) {
          FilterChip(
            selected = false,
            onClick = { onDateFilterChange(null) },
            leadingIcon = {
              Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
            },
            label = { Text("তারিখ সরান") },
            modifier = Modifier.testTag("search_clear_date_chip"),
          )
        }

        Spacer(Modifier.weight(1f))

        Text(
          text = "${BengaliFormatters.toBengaliDigits(results.size)}টি ফলাফল",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (results.isEmpty()) {
        EmptyLedgerState(
          title = "কোনো মিল পাওয়া যায়নি",
          subtitle = "অন্য দোকানের নাম, তারিখ অথবা মেমো নম্বর লিখে আবার চেষ্টা করুন।",
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize().testTag("search_results_list"),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 16.dp),
        ) {
          items(results, key = { it.id }) { record ->
            SavedLedgerCard(
              record = record,
              onEdit = { onEditRecord(record) },
              onSharePdf = { onSharePdfRecord(record) },
              onPrint = { onPrintRecord(record) },
              onDelete = { onDeleteRecord(record) },
            )
          }
        }
      }
    }
  }
}
