package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SocialLinks
import com.example.ui.theme.PlusJakartaFamily

/**
 * Permanent, compact social media footer hardcoded directly to SocialLinks.
 * Does not take space away from the main ledger form and cannot be edited from Settings.
 */
@Composable
fun PermanentSocialMediaFooter(modifier: Modifier = Modifier) {
  val context = LocalContext.current

  Surface(
    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
    tonalElevation = 2.dp,
    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
    modifier = modifier.fillMaxWidth().testTag("permanent_social_footer"),
  ) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 12.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "AF-ARIF",
        fontFamily = PlusJakartaFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.primary,
      )

      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        SocialIconPill(
          label = "TikTok",
          backgroundBrush = Brush.linearGradient(listOf(Color(0xFF111111), Color(0xFF2B2B2B))),
          contentDesc = "TikTok খুলুন",
          testTag = "social_tiktok_button",
          onClick = { openExternalLink(context, SocialLinks.TIKTOK_URL) },
        ) {
          TikTokGlyph(modifier = Modifier.size(16.dp))
        }

        SocialIconPill(
          label = "Telegram",
          backgroundBrush = Brush.linearGradient(listOf(Color(0xFF0088CC), Color(0xFF29B6F6))),
          contentDesc = "Telegram খুলুন",
          testTag = "social_telegram_button",
          onClick = { openExternalLink(context, SocialLinks.TELEGRAM_URL) },
        ) {
          TelegramGlyph(modifier = Modifier.size(16.dp))
        }

        SocialIconPill(
          label = "Facebook",
          backgroundBrush = Brush.linearGradient(listOf(Color(0xFF1877F2), Color(0xFF0D5BD9))),
          contentDesc = "Facebook খুলুন",
          testTag = "social_facebook_button",
          onClick = { openExternalLink(context, SocialLinks.FACEBOOK_URL) },
        ) {
          FacebookGlyph(modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}

@Composable
private fun SocialIconPill(
  label: String,
  backgroundBrush: Brush,
  contentDesc: String,
  testTag: String,
  onClick: () -> Unit,
  iconContent: @Composable () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  Box(
    modifier =
      Modifier.minimumInteractiveComponentSize()
        .height(34.dp)
        .clip(RoundedCornerShape(17.dp))
        .background(backgroundBrush)
        .bouncePressEffect(interactionSource)
        .clickable(
          interactionSource = interactionSource,
          indication = androidx.compose.material3.ripple(color = Color.White),
          onClick = onClick,
        )
        .semantics { contentDescription = contentDesc }
        .testTag(testTag)
        .padding(horizontal = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier.size(20.dp).clip(CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        iconContent()
      }
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = label,
        fontFamily = PlusJakartaFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        color = Color.White,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun TikTokGlyph(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    // Stylized musical note inspired by TikTok with cyan + magenta accent
    val cyanStroke = Stroke(width = w * 0.16f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val notePath =
      Path().apply {
        moveTo(w * 0.62f, h * 0.16f)
        lineTo(w * 0.62f, h * 0.68f)
        cubicTo(w * 0.62f, h * 0.86f, w * 0.34f, h * 0.90f, w * 0.26f, h * 0.74f)
        cubicTo(w * 0.20f, h * 0.60f, w * 0.34f, h * 0.48f, w * 0.48f, h * 0.54f)
        moveTo(w * 0.62f, h * 0.22f)
        cubicTo(w * 0.70f, h * 0.36f, w * 0.80f, h * 0.40f, w * 0.88f, h * 0.40f)
      }
    drawPath(notePath, color = Color(0xFF25F4EE), style = cyanStroke)
    drawPath(
      notePath,
      color = Color.White,
      style = Stroke(width = w * 0.12f, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
  }
}

@Composable
private fun TelegramGlyph(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val plane =
      Path().apply {
        moveTo(w * 0.90f, h * 0.16f)
        lineTo(w * 0.10f, h * 0.48f)
        lineTo(w * 0.40f, h * 0.58f)
        lineTo(w * 0.76f, h * 0.28f)
        lineTo(w * 0.48f, h * 0.64f)
        lineTo(w * 0.74f, h * 0.86f)
        close()
      }
    drawPath(plane, color = Color.White)
  }
}

@Composable
private fun FacebookGlyph(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val fStroke = Stroke(width = w * 0.18f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val fPath =
      Path().apply {
        moveTo(w * 0.72f, h * 0.16f)
        lineTo(w * 0.58f, h * 0.16f)
        cubicTo(w * 0.48f, h * 0.16f, w * 0.46f, h * 0.26f, w * 0.46f, h * 0.36f)
        lineTo(w * 0.46f, h * 0.88f)
      }
    drawPath(fPath, color = Color.White, style = fStroke)
    drawLine(
      color = Color.White,
      start = Offset(w * 0.30f, h * 0.50f),
      end = Offset(w * 0.68f, h * 0.50f),
      strokeWidth = w * 0.16f,
      cap = StrokeCap.Round,
    )
  }
}

private fun openExternalLink(context: Context, url: String) {
  runCatching {
    val intent =
      Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    context.startActivity(intent)
  }.onFailure {
    Toast.makeText(context, "লিংক খোলার জন্য ব্রাউজার পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
  }
}
