package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = DarkBluePrimary,
    onPrimary = Color(0xFF041E49),
    primaryContainer = DarkTableHeader,
    onPrimaryContainer = TextPrimaryDark,
    secondary = DarkCyanAccent,
    onSecondary = Color(0xFF002026),
    secondaryContainer = Color(0xFF1A345C),
    onSecondaryContainer = TextPrimaryDark,
    tertiary = Color(0xFF82B1FF),
    background = DarkNavyBackground,
    onBackground = TextPrimaryDark,
    surface = DarkNavySurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkNavySurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    outline = DarkTableBorder,
    error = DarkDangerRed,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = RoyalBluePrimary,
    onPrimary = Color.White,
    primaryContainer = SoftBlueTint,
    onPrimaryContainer = RoyalBluePrimary,
    secondary = SkyBlueAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6EEFF),
    onSecondaryContainer = Color(0xFF003258),
    tertiary = CyanHighlight,
    background = IceBlueBackground,
    onBackground = TextPrimaryLight,
    surface = GlassWhiteSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFEAF1FD),
    onSurfaceVariant = TextSecondaryLight,
    outline = TableBorderLight,
    error = DangerRed,
  )

@Composable
fun AfArifHisabTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = AppTypography, content = content)
}
