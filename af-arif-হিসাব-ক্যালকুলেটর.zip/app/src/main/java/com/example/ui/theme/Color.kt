package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Royal Blue Palette (Light)
val RoyalBluePrimary = Color(0xFF0D47A1)
val RoyalBlueBright = Color(0xFF1565C0)
val SkyBlueAccent = Color(0xFF0288D1)
val CyanHighlight = Color(0xFF00ACC1)
val IceBlueBackground = Color(0xFFF3F7FE)
val GlassWhiteSurface = Color(0xFFFFFFFF)
val SoftBlueTint = Color(0xFFE3EEFF)
val TableHeaderBlue = Color(0xFF103F91)
val TableStripeLight = Color(0xFFF7FAFF)
val TableBorderLight = Color(0xFFD0DFF5)
val TextPrimaryLight = Color(0xFF0B1F3A)
val TextSecondaryLight = Color(0xFF4A607A)
val SuccessGreen = Color(0xFF1B8A4E)
val DangerRed = Color(0xFFC62828)

// Dark Mode Navy Palette
val DarkNavyBackground = Color(0xFF081222)
val DarkNavySurface = Color(0xFF101E36)
val DarkNavySurfaceElevated = Color(0xFF162745)
val DarkBluePrimary = Color(0xFF64B5F6)
val DarkCyanAccent = Color(0xFF4DD0E1)
val DarkTableHeader = Color(0xFF13336B)
val DarkTableStripe = Color(0xFF13223D)
val DarkTableBorder = Color(0xFF263E66)
val TextPrimaryDark = Color(0xFFEEF4FF)
val TextSecondaryDark = Color(0xFFA3B8D6)
val DarkSuccessGreen = Color(0xFF66BB6A)
val DarkDangerRed = Color(0xFFEF5350)
