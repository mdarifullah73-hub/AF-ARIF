package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.PlusJakartaFamily
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SkyBlueAccent
import com.example.ui.theme.SuccessGreen
import com.example.util.BengaliFormatters

/**
 * Adds smooth press-down spring scale feedback alongside Material ripple.
 */
fun Modifier.bouncePressEffect(interactionSource: MutableInteractionSource): Modifier = composed {
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by
    animateFloatAsState(
      targetValue = if (isPressed) 0.94f else 1f,
      animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
      label = "bounce_press",
    )
  this.graphicsLayer {
    scaleX = scale
    scaleY = scale
  }
}

@Composable
fun AnimatedBengaliCounter(
  targetValue: Long,
  suffix: String = "",
  style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.titleLarge,
  color: Color = MaterialTheme.colorScheme.onSurface,
  modifier: Modifier = Modifier,
) {
  val clampedTarget = targetValue.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
  val animatedCount by
    animateIntAsState(
      targetValue = clampedTarget,
      animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
      label = "counter_anim",
    )
  val formatted = BengaliFormatters.toBengaliDigits(animatedCount)
  Text(
    text = if (suffix.isEmpty()) formatted else "$formatted $suffix",
    style = style,
    color = color,
    maxLines = 1,
    modifier = modifier,
  )
}

@Composable
fun WelcomeSplashOverlay(
  visible: Boolean,
  onSkip: () -> Unit,
) {
  AnimatedVisibility(
    visible = visible,
    enter = fadeIn(tween(250)),
    exit = fadeOut(tween(420)) + scaleOut(targetScale = 1.06f, animationSpec = tween(420)),
  ) {
    val logoScale = remember { Animatable(0.72f) }
    LaunchedEffect(Unit) {
      logoScale.animateTo(
        targetValue = 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
      )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
    val haloAlpha by
      infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.65f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "halo_alpha",
      )

    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(Color(0xFF06255C), RoyalBluePrimary, RoyalBlueBright, SkyBlueAccent)
            )
          )
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onSkip,
          )
          .testTag("welcome_overlay"),
      contentAlignment = Alignment.Center,
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(32.dp).scale(logoScale.value),
      ) {
        Box(
          modifier =
            Modifier.size(112.dp)
              .clip(RoundedCornerShape(28.dp))
              .background(Color.White.copy(alpha = 0.14f + haloAlpha * 0.08f))
              .padding(16.dp),
          contentAlignment = Alignment.Center,
        ) {
          Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            shadowElevation = 12.dp,
            modifier = Modifier.fillMaxSize(),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Rounded.Calculate,
                contentDescription = "AF-ARIF লোগো",
                tint = RoyalBluePrimary,
                modifier = Modifier.size(48.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = "AF-ARIF",
          fontFamily = PlusJakartaFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 30.sp,
          letterSpacing = 2.sp,
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "হিসাব ক্যালকুলেটর",
          style = MaterialTheme.typography.headlineMedium,
          color = Color(0xFFDCEBFF),
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Surface(
          shape = CircleShape,
          color = Color.White.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
        ) {
          Text(
            text = "৪০ সারির স্মার্ট ডিজিটাল হিসাব খাতা",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
          )
        }
        Spacer(modifier = Modifier.height(28.dp))
        CircularProgressIndicator(
          color = Color.White,
          trackColor = Color.White.copy(alpha = 0.25f),
          strokeWidth = 3.dp,
          modifier = Modifier.size(28.dp),
        )
      }
    }
  }
}

@Composable
fun SaveSuccessPopupDialog(
  visible: Boolean,
  title: String,
  subtitle: String,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = true),
  ) {
    val popScale = remember { Animatable(0.75f) }
    LaunchedEffect(visible) {
      popScale.animateTo(
        1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
      )
    }

    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
      modifier = Modifier.fillMaxWidth().scale(popScale.value).testTag("save_success_dialog"),
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().padding(24.dp),
      ) {
        Box(
          modifier =
            Modifier.size(72.dp)
              .clip(CircleShape)
              .background(SuccessGreen.copy(alpha = 0.14f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Rounded.CheckCircle,
            contentDescription = "সফল",
            tint = SuccessGreen,
            modifier = Modifier.size(48.dp),
          )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center,
        )
        if (subtitle.isNotBlank()) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
        }
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_success_ok_button"),
        ) {
          Text("ঠিক আছে", style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
fun DeleteConfirmDialog(
  visible: Boolean,
  title: String,
  message: String,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  Dialog(onDismissRequest = onDismiss) {
    val scale = remember { Animatable(0.82f) }
    LaunchedEffect(visible) {
      scale.animateTo(
        1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
      )
    }

    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
      modifier = Modifier.fillMaxWidth().scale(scale.value).testTag("delete_confirm_dialog"),
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().padding(24.dp),
      ) {
        Box(
          modifier =
            Modifier.size(64.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.error.copy(alpha = 0.14f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Rounded.DeleteForever,
            contentDescription = "সতর্কতা",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(36.dp),
          )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = message,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(20.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedButton(
            onClick = onDismiss,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("delete_cancel_button"),
          ) {
            Text("বাতিল")
          }
          Button(
            onClick = onConfirm,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("delete_confirm_button"),
          ) {
            Text("মুছে ফেলুন")
          }
        }
      }
    }
  }
}

@Composable
fun LoadingOverlay(visible: Boolean, message: String) {
  AnimatedVisibility(
    visible = visible,
    enter = fadeIn(tween(150)) + scaleIn(initialScale = 0.92f, animationSpec = tween(150)),
    exit = fadeOut(tween(150)),
  ) {
    Box(
      modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.42f)).testTag("loading_overlay"),
      contentAlignment = Alignment.Center,
    ) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp),
        ) {
          CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 3.dp)
          Spacer(modifier = Modifier.width(16.dp))
          Text(text = message, style = MaterialTheme.typography.titleMedium)
        }
      }
    }
  }
}
