package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Scale
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActiveLedgerSheet
import com.example.data.LedgerRow
import com.example.data.LedgerTotals
import com.example.data.TOTAL_LEDGER_ROWS
import com.example.ui.components.AnimatedBengaliCounter
import com.example.ui.components.bouncePressEffect
import com.example.ui.theme.HindSiliguriFamily
import com.example.ui.theme.PlusJakartaFamily
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SkyBlueAccent
import com.example.util.BengaliFormatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
  sheet: ActiveLedgerSheet,
  totals: LedgerTotals,
  isDarkTheme: Boolean,
  onMemoNoChange: (String) -> Unit,
  onDateChange: (Long) -> Unit,
  onPartyNameChange: (String) -> Unit,
  onRowChange: (serial: Int, pieces: String?, kg: String?, gram: String?, shopName: String?) -> Unit,
  onClearRow: (Int) -> Unit,
  onNewSheet: () -> Unit,
  onSaveSheet: () -> Unit,
  onSavePdfDocument: () -> Unit,
  onSharePdf: () -> Unit,
  onPrintLedger: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showDatePicker by remember { mutableStateOf(false) }
  var showPdfOptionsDialog by remember { mutableStateOf(false) }

  if (showDatePicker) {
    val pickerState = rememberDatePickerState(initialSelectedDateMillis = sheet.dateMillis)
    DatePickerDialog(
      onDismissRequest = { showDatePicker = false },
      confirmButton = {
        TextButton(
          onClick = {
            pickerState.selectedDateMillis?.let { onDateChange(it) }
            showDatePicker = false
          },
          modifier = Modifier.testTag("date_picker_confirm"),
        ) {
          Text("নির্বাচন করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDatePicker = false }) { Text("বাতিল") }
      },
    ) {
      DatePicker(state = pickerState)
    }
  }

  if (showPdfOptionsDialog) {
    AlertDialog(
      onDismissRequest = { showPdfOptionsDialog = false },
      title = { Text("PDF ও প্রিন্ট অপশন", style = MaterialTheme.typography.titleLarge) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "৪০টি ক্রমিক নম্বর, পিস, কেজি, গ্রাম, দোকানের নাম ও মোট হিসাবসহ পরিষ্কার PDF তৈরি হবে।",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Button(
            onClick = {
              showPdfOptionsDialog = false
              onSavePdfDocument()
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("dialog_save_pdf_button"),
          ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("ফোনে PDF সেভ করুন")
          }
          OutlinedButton(
            onClick = {
              showPdfOptionsDialog = false
              onSharePdf()
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("dialog_share_pdf_button"),
          ) {
            Icon(Icons.Rounded.Share, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("PDF শেয়ার করুন")
          }
          OutlinedButton(
            onClick = {
              showPdfOptionsDialog = false
              onPrintLedger()
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("dialog_print_button"),
          ) {
            Icon(Icons.Rounded.Print, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("সরাসরি প্রিন্ট করুন")
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showPdfOptionsDialog = false }) { Text("বন্ধ করুন") }
      },
    )
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 760.dp).padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
      // 1. Compact Premium Gradient Brand & Action Header
      BrandHeaderCard(
        isEditing = sheet.editingRecordId != null,
        filledCount = totals.filledRowCount,
        onNewSheet = onNewSheet,
        onSaveSheet = onSaveSheet,
        onPdfClick = { showPdfOptionsDialog = true },
        onPrintClick = onPrintLedger,
      )

      Spacer(modifier = Modifier.height(6.dp))

      // 2. Memo Metadata Card (নং, তারিখ, নাম — matching reference form)
      MemoMetadataCard(
        memoNo = sheet.memoNo,
        dateMillis = sheet.dateMillis,
        partyName = sheet.partyName,
        isDarkTheme = isDarkTheme,
        onMemoNoChange = onMemoNoChange,
        onOpenDatePicker = { showDatePicker = true },
        onPartyNameChange = onPartyNameChange,
      )

      Spacer(modifier = Modifier.height(6.dp))

      // 3. 40-Row Ledger Table Card (Pinned Royal Blue Header + 40 Scrollable Rows)
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.weight(1f).fillMaxWidth(),
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          // Royal Blue Table Header matching reference sheet
          LedgerTableHeader(isDarkTheme = isDarkTheme)

          LazyColumn(
            modifier = Modifier.fillMaxSize().testTag("ledger_rows_list"),
            contentPadding = PaddingValues(bottom = 8.dp),
          ) {
            items(items = sheet.rows, key = { it.serial }) { row ->
              LedgerTableRowItem(
                row = row,
                isDarkTheme = isDarkTheme,
                onPiecesChange = { onRowChange(row.serial, it, null, null, null) },
                onKgChange = { onRowChange(row.serial, null, it, null, null) },
                onGramChange = { onRowChange(row.serial, null, null, it, null) },
                onShopNameChange = { onRowChange(row.serial, null, null, null, it) },
                onClearRow = { onClearRow(row.serial) },
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // 4. Three Glassmorphic Summary Cards + Save Action
      SummaryCardsSection(
        totals = totals,
        isEditing = sheet.editingRecordId != null,
        isDarkTheme = isDarkTheme,
        onSaveClick = onSaveSheet,
      )
    }
  }
}

@Composable
private fun BrandHeaderCard(
  isEditing: Boolean,
  filledCount: Int,
  onNewSheet: () -> Unit,
  onSaveSheet: () -> Unit,
  onPdfClick: () -> Unit,
  onPrintClick: () -> Unit,
) {
  Box(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(
          Brush.linearGradient(
            colors = listOf(Color(0xFF0A3378), RoyalBluePrimary, RoyalBlueBright, SkyBlueAccent)
          )
        )
        .padding(horizontal = 12.dp, vertical = 8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "AF-ARIF",
            fontFamily = PlusJakartaFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White,
            letterSpacing = 0.8.sp,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.18f),
          ) {
            Text(
              text = if (isEditing) "সম্পাদনা" else "নতুন খাতা",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            )
          }
        }
        Text(
          text =
            "হিসাব ক্যালকুলেটর • ${BengaliFormatters.toBengaliDigits(filledCount)}/${BengaliFormatters.toBengaliDigits(TOTAL_LEDGER_ROWS)} সারি",
          style = MaterialTheme.typography.bodySmall,
          color = Color(0xFFDCEBFF),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        HeaderIconAction(
          icon = Icons.Rounded.NoteAdd,
          contentDesc = "নতুন হিসাব",
          testTag = "new_sheet_button",
          onClick = onNewSheet,
        )
        HeaderIconAction(
          icon = Icons.Rounded.PictureAsPdf,
          contentDesc = "PDF অপশন",
          testTag = "pdf_options_button",
          onClick = onPdfClick,
        )
        HeaderIconAction(
          icon = Icons.Rounded.Print,
          contentDesc = "প্রিন্ট করুন",
          testTag = "print_sheet_button",
          onClick = onPrintClick,
        )
        HeaderIconAction(
          icon = Icons.Rounded.Save,
          contentDesc = "সংরক্ষণ করুন",
          testTag = "header_save_button",
          containerColor = Color.White,
          iconTint = RoyalBluePrimary,
          onClick = onSaveSheet,
        )
      }
    }
  }
}

@Composable
private fun HeaderIconAction(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  contentDesc: String,
  testTag: String,
  containerColor: Color = Color.White.copy(alpha = 0.18f),
  iconTint: Color = Color.White,
  onClick: () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  FilledTonalIconButton(
    onClick = onClick,
    interactionSource = interactionSource,
    colors = IconButtonDefaults.filledTonalIconButtonColors(
      containerColor = containerColor,
      contentColor = iconTint,
    ),
    modifier = Modifier.size(38.dp).bouncePressEffect(interactionSource).testTag(testTag),
  ) {
    Icon(imageVector = icon, contentDescription = contentDesc, modifier = Modifier.size(19.dp))
  }
}

@Composable
private fun MemoMetadataCard(
  memoNo: String,
  dateMillis: Long,
  partyName: String,
  isDarkTheme: Boolean,
  onMemoNoChange: (String) -> Unit,
  onOpenDatePicker: () -> Unit,
  onPartyNameChange: (String) -> Unit,
) {
  val cardBg =
    if (isDarkTheme) MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
    else Color.White.copy(alpha = 0.94f)

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = cardBg,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        // নং:
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier =
            Modifier.weight(0.42f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
              .padding(horizontal = 8.dp, vertical = 6.dp),
        ) {
          Text(
            text = "নং:",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
          )
          Spacer(Modifier.width(6.dp))
          BasicTextField(
            value = memoNo,
            onValueChange = onMemoNoChange,
            singleLine = true,
            textStyle =
              TextStyle(
                fontFamily = HindSiliguriFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface,
              ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth().testTag("memo_no_input"),
          )
        }

        // তারিখ:
        val dateInteraction = remember { MutableInteractionSource() }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier =
            Modifier.weight(0.58f)
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
              .bouncePressEffect(dateInteraction)
              .clickable(interactionSource = dateInteraction, indication = androidx.compose.material3.ripple(), onClick = onOpenDatePicker)
              .padding(horizontal = 10.dp, vertical = 6.dp)
              .testTag("memo_date_button"),
        ) {
          Text(
            text = "তারিখ: ${BengaliFormatters.formatDateDisplay(dateMillis)}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Icon(
            imageVector = Icons.Rounded.CalendarMonth,
            contentDescription = "তারিখ পরিবর্তন করুন",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // নাম:
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
      ) {
        Text(
          text = "নাম:",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.width(8.dp))
        Box(modifier = Modifier.fillMaxWidth()) {
          if (partyName.isEmpty()) {
            Text(
              text = "ক্রেতা / পার্টির নাম লিখুন...",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
          }
          BasicTextField(
            value = partyName,
            onValueChange = onPartyNameChange,
            singleLine = true,
            textStyle =
              TextStyle(
                fontFamily = HindSiliguriFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 13.5.sp,
                color = MaterialTheme.colorScheme.onSurface,
              ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth().testTag("party_name_input"),
          )
        }
      }
    }
  }
}

@Composable
private fun LedgerTableHeader(isDarkTheme: Boolean) {
  val headerBg =
    if (isDarkTheme) {
      Brush.horizontalGradient(listOf(Color(0xFF0E2B5C), Color(0xFF153E82)))
    } else {
      Brush.horizontalGradient(listOf(Color(0xFF0D3A8A), Color(0xFF1553B8)))
    }

  Row(
    modifier = Modifier.fillMaxWidth().background(headerBg).padding(vertical = 8.dp, horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    TableHeaderCell("ক্রমিক", Modifier.weight(0.12f))
    TableHeaderCell("পিস", Modifier.weight(0.16f))
    TableHeaderCell("কেজি", Modifier.weight(0.16f))
    TableHeaderCell("গ্রাম", Modifier.weight(0.18f))
    TableHeaderCell("দোকানের নাম", Modifier.weight(0.38f))
  }
}

@Composable
private fun TableHeaderCell(label: String, modifier: Modifier) {
  Text(
    text = label,
    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
    color = Color.White,
    textAlign = TextAlign.Center,
    maxLines = 1,
    overflow = TextOverflow.Ellipsis,
    modifier = modifier.padding(horizontal = 2.dp),
  )
}

@Composable
private fun LedgerTableRowItem(
  row: LedgerRow,
  isDarkTheme: Boolean,
  onPiecesChange: (String) -> Unit,
  onKgChange: (String) -> Unit,
  onGramChange: (String) -> Unit,
  onShopNameChange: (String) -> Unit,
  onClearRow: () -> Unit,
) {
  val hasData = !row.isEmpty
  val targetBg =
    when {
      hasData && isDarkTheme -> Color(0xFF18335E)
      hasData && !isDarkTheme -> Color(0xFFE7F1FF)
      row.serial % 2 == 0 && isDarkTheme -> Color(0xFF12213B)
      row.serial % 2 == 0 && !isDarkTheme -> Color(0xFFF6FAFF)
      else -> MaterialTheme.colorScheme.surface
    }
  val rowBg by animateColorAsState(targetValue = targetBg, animationSpec = tween(200), label = "row_bg")
  val borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)

  Column(modifier = Modifier.fillMaxWidth().background(rowBg)) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
      // 1. ক্রমিক (০১ - ৪০)
      Box(
        modifier =
          Modifier.weight(0.12f)
            .height(38.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(
              if (hasData) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
              else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = BengaliFormatters.formatSerial(row.serial),
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
          textAlign = TextAlign.Center,
        )
      }

      // 2. পিস
      LedgerCellInput(
        value = row.pieces,
        onValueChange = onPiecesChange,
        placeholder = "০",
        keyboardType = KeyboardType.Number,
        textAlign = TextAlign.Center,
        borderColor = borderColor,
        testTag = "row_${row.serial}_pieces",
        modifier = Modifier.weight(0.16f),
      )

      // 3. কেজি
      LedgerCellInput(
        value = row.kg,
        onValueChange = onKgChange,
        placeholder = "০",
        keyboardType = KeyboardType.Number,
        textAlign = TextAlign.Center,
        borderColor = borderColor,
        testTag = "row_${row.serial}_kg",
        modifier = Modifier.weight(0.16f),
      )

      // 4. গ্রাম
      LedgerCellInput(
        value = row.gram,
        onValueChange = onGramChange,
        placeholder = "০",
        keyboardType = KeyboardType.Number,
        textAlign = TextAlign.Center,
        borderColor = borderColor,
        testTag = "row_${row.serial}_gram",
        modifier = Modifier.weight(0.18f),
      )

      // 5. দোকানের নাম + optional clear button when non-empty
      Box(modifier = Modifier.weight(0.38f), contentAlignment = Alignment.CenterEnd) {
        LedgerCellInput(
          value = row.shopName,
          onValueChange = onShopNameChange,
          placeholder = "দোকান",
          keyboardType = KeyboardType.Text,
          textAlign = TextAlign.Start,
          borderColor = borderColor,
          trailingPaddingDp = if (hasData) 22 else 6,
          testTag = "row_${row.serial}_shop",
          modifier = Modifier.fillMaxWidth(),
        )
        androidx.compose.animation.AnimatedVisibility(visible = hasData, enter = fadeIn(), exit = fadeOut()) {
          IconButton(
            onClick = onClearRow,
            modifier = Modifier.size(26.dp).testTag("row_${row.serial}_clear"),
          ) {
            Icon(
              imageVector = Icons.Rounded.Close,
              contentDescription = "সারি মুছুন",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(14.dp),
            )
          }
        }
      }
    }
    Box(modifier = Modifier.fillMaxWidth().height(0.5.dp).background(borderColor))
  }
}

@Composable
private fun LedgerCellInput(
  value: String,
  onValueChange: (String) -> Unit,
  placeholder: String,
  keyboardType: KeyboardType,
  textAlign: TextAlign,
  borderColor: Color,
  trailingPaddingDp: Int = 4,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .height(38.dp)
        .clip(RoundedCornerShape(7.dp))
        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.78f))
        .border(0.8.dp, borderColor, RoundedCornerShape(7.dp))
        .padding(start = 5.dp, end = trailingPaddingDp.dp),
    contentAlignment = if (textAlign == TextAlign.Center) Alignment.Center else Alignment.CenterStart,
  ) {
    if (value.isEmpty()) {
      Text(
        text = placeholder,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.42f),
        textAlign = textAlign,
        maxLines = 1,
        modifier = Modifier.fillMaxWidth(),
      )
    }
    BasicTextField(
      value = value,
      onValueChange = onValueChange,
      singleLine = true,
      keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = ImeAction.Next),
      textStyle =
        TextStyle(
          fontFamily = HindSiliguriFamily,
          fontWeight = FontWeight.Medium,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = textAlign,
        ),
      cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
      modifier = Modifier.fillMaxWidth().testTag(testTag),
    )
  }
}

@Composable
private fun SummaryCardsSection(
  totals: LedgerTotals,
  isEditing: Boolean,
  isDarkTheme: Boolean,
  onSaveClick: () -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    // 3 Glassmorphic Summary Cards
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      // Card 1: সর্বমোট পিস
      GlassSummaryCard(
        title = "সর্বমোট পিস",
        accentBrush = Brush.linearGradient(listOf(Color(0xFF0D47A1), Color(0xFF1976D2))),
        isDarkTheme = isDarkTheme,
        modifier = Modifier.weight(0.9f).testTag("summary_total_pieces_card"),
      ) {
        AnimatedBengaliCounter(
          targetValue = totals.totalPieces,
          suffix = "পিস",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
        )
      }

      // Card 2: সর্বমোট কেজি
      GlassSummaryCard(
        title = "সর্বমোট কেজি",
        accentBrush = Brush.linearGradient(listOf(Color(0xFF0277BD), Color(0xFF00ACC1))),
        isDarkTheme = isDarkTheme,
        modifier = Modifier.weight(0.95f).testTag("summary_total_kg_card"),
      ) {
        AnimatedBengaliCounter(
          targetValue = totals.finalKg,
          suffix = "কেজি",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.secondary,
        )
      }

      // Card 3: সর্বমোট গ্রাম ও সম্মিলিত ওজন
      GlassSummaryCard(
        title = "গ্রাম ও সম্মিলিত ওজন",
        accentBrush = Brush.linearGradient(listOf(Color(0xFF1565C0), Color(0xFF26A69A))),
        isDarkTheme = isDarkTheme,
        modifier = Modifier.weight(1.35f).testTag("summary_total_gram_card"),
      ) {
        AnimatedBengaliCounter(
          targetValue = totals.remainingGram,
          suffix = "গ্রাম",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = totals.combinedWeightText,
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    // Primary Save / Update CTA Button
    val saveInteraction = remember { MutableInteractionSource() }
    Button(
      onClick = onSaveClick,
      interactionSource = saveInteraction,
      shape = RoundedCornerShape(14.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = Color.White,
        ),
      modifier =
        Modifier.fillMaxWidth()
          .height(48.dp)
          .bouncePressEffect(saveInteraction)
          .testTag("save_ledger_button"),
    ) {
      Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(20.dp))
      Spacer(Modifier.width(8.dp))
      Text(
        text = if (isEditing) "হিসাব হালনাগাদ করুন" else "হিসাব সংরক্ষণ করুন",
        style = MaterialTheme.typography.labelLarge,
      )
    }
  }
}

@Composable
private fun GlassSummaryCard(
  title: String,
  accentBrush: Brush,
  isDarkTheme: Boolean,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit,
) {
  val bgColor =
    if (isDarkTheme) MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)
    else Color.White.copy(alpha = 0.90f)

  Surface(
    shape = RoundedCornerShape(14.dp),
    color = bgColor,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)),
    tonalElevation = 2.dp,
    shadowElevation = 2.dp,
    modifier = modifier,
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Box(modifier = Modifier.fillMaxWidth().height(4.dp).background(accentBrush))
      Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
        Text(
          text = title,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        content()
      }
    }
  }
}
