package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ThemeMode
import com.example.ui.components.bouncePressEffect
import com.example.ui.theme.RoyalBlueBright
import com.example.ui.theme.RoyalBluePrimary
import com.example.util.BengaliFormatters

/**
 * App Settings Screen.
 * Note: Intentionally provides NO options to edit, remove, or alter Social Media Links.
 */
@Composable
fun SettingsScreen(
  themeMode: ThemeMode,
  totalSavedCount: Int,
  onThemeModeChange: (ThemeMode) -> Unit,
  onBackupClick: () -> Unit,
  onRestoreClick: () -> Unit,
  onExportCsvClick: () -> Unit,
  onViewHistoryClick: () -> Unit,
  onDeleteAllClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 760.dp)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Header
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(RoyalBluePrimary, RoyalBlueBright)))
            .padding(horizontal = 16.dp, vertical = 14.dp),
      ) {
        Column {
          Text(
            text = "অ্যাপ সেটিংস",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
          )
          Text(
            text = "থিম, ডেটা ব্যাকআপ, রিস্টোর ও এক্সপোর্ট পরিচালনা করুন",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFDCEBFF),
          )
        }
      }

      // Theme Mode Card
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
          Text(
            text = "অ্যাপের থিম (Light / Dark Mode)",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            ThemeOptionChip(
              label = "লাইট",
              icon = Icons.Rounded.LightMode,
              selected = themeMode == ThemeMode.LIGHT,
              onClick = { onThemeModeChange(ThemeMode.LIGHT) },
              testTag = "theme_light_chip",
              modifier = Modifier.weight(1f),
            )
            ThemeOptionChip(
              label = "ডার্ক",
              icon = Icons.Rounded.DarkMode,
              selected = themeMode == ThemeMode.DARK,
              onClick = { onThemeModeChange(ThemeMode.DARK) },
              testTag = "theme_dark_chip",
              modifier = Modifier.weight(1f),
            )
            ThemeOptionChip(
              label = "সিস্টেম",
              icon = Icons.Rounded.PhoneAndroid,
              selected = themeMode == ThemeMode.SYSTEM,
              onClick = { onThemeModeChange(ThemeMode.SYSTEM) },
              testTag = "theme_system_chip",
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Data Management Section
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = "ডেটা ও হিসাব ব্যবস্থাপনা",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
          )

          SettingsActionRow(
            icon = Icons.Rounded.History,
            title = "পুরোনো হিসাব দেখুন",
            subtitle = "মোট ${BengaliFormatters.toBengaliDigits(totalSavedCount)}টি সংরক্ষিত হিসাব",
            tint = MaterialTheme.colorScheme.primary,
            testTag = "settings_view_history",
            onClick = onViewHistoryClick,
          )

          SettingsActionRow(
            icon = Icons.Rounded.Backup,
            title = "ডেটা ব্যাকআপ (Backup)",
            subtitle = "সকল হিসাব JSON ফাইলে নিরাপদে সংরক্ষণ করুন",
            tint = MaterialTheme.colorScheme.primary,
            testTag = "settings_backup_button",
            onClick = onBackupClick,
          )

          SettingsActionRow(
            icon = Icons.Rounded.Restore,
            title = "ডেটা রিস্টোর (Restore)",
            subtitle = "আগের JSON ব্যাকআপ ফাইল থেকে হিসাব ফিরিয়ে আনুন",
            tint = MaterialTheme.colorScheme.secondary,
            testTag = "settings_restore_button",
            onClick = onRestoreClick,
          )

          SettingsActionRow(
            icon = Icons.Rounded.Download,
            title = "হিসাব এক্সপোর্ট (CSV)",
            subtitle = "এক্সেল বা গুগল শিটে খোলার জন্য CSV ফাইল তৈরি করুন",
            tint = MaterialTheme.colorScheme.primary,
            testTag = "settings_export_csv",
            onClick = onExportCsvClick,
          )

          SettingsActionRow(
            icon = Icons.Rounded.DeleteSweep,
            title = "সকল হিসাব মুছে ফেলুন",
            subtitle = "সংরক্ষিত সমস্ত হিসাব স্থায়ীভাবে মুছে ফেলুন",
            tint = MaterialTheme.colorScheme.error,
            testTag = "settings_delete_all",
            onClick = onDeleteAllClick,
          )
        }
      }

      // App Info & Version Card
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier.fillMaxWidth().testTag("app_info_card"),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier =
                Modifier.size(44.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center,
            ) {
              Icon(Icons.Rounded.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column {
              Text(
                text = "AF-ARIF হিসাব ক্যালকুলেটর",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = "ব্র্যান্ড: AF-ARIF • ভার্সন ১.০.০",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(10.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.VerifiedUser,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
              )
              Spacer(Modifier.width(8.dp))
              Text(
                text = "সম্পূর্ণ অফলাইন সমর্থিত • সকল হিসাব আপনার মোবাইলে নিরাপদে সংরক্ষিত থাকে।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
    }
  }
}

@Composable
private fun ThemeOptionChip(
  label: String,
  icon: ImageVector,
  selected: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  FilterChip(
    selected = selected,
    onClick = onClick,
    leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
    label = { Text(label, style = MaterialTheme.typography.labelMedium) },
    modifier = modifier.height(44.dp).testTag(testTag),
  )
}

@Composable
private fun SettingsActionRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  tint: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  val interaction = remember { MutableInteractionSource() }
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier =
      Modifier.fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(14.dp))
        .bouncePressEffect(interaction)
        .clickable(
          interactionSource = interaction,
          indication = androidx.compose.material3.ripple(),
          onClick = onClick,
        )
        .padding(horizontal = 10.dp, vertical = 10.dp)
        .testTag(testTag),
  ) {
    Box(
      modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.12f)),
      contentAlignment = Alignment.Center,
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
    }
    Spacer(Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
