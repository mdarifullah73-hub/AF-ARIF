package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.ThemeMode
import com.example.export.PdfAndPrintManager
import com.example.ui.AppDestination
import com.example.ui.HisabViewModel
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.LoadingOverlay
import com.example.ui.components.PermanentSocialMediaFooter
import com.example.ui.components.SaveSuccessPopupDialog
import com.example.ui.components.WelcomeSplashOverlay
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AfArifHisabTheme
import com.example.util.BengaliFormatters

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent { AfArifHisabApp() }
  }
}

@Composable
fun AfArifHisabApp(viewModel: HisabViewModel = viewModel()) {
  val context = LocalContext.current
  val sheet by viewModel.activeSheet.collectAsStateWithLifecycle()
  val totals by viewModel.totals.collectAsStateWithLifecycle()
  val savedRecords by viewModel.savedRecords.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val searchDateMillis by viewModel.searchDateMillis.collectAsStateWithLifecycle()
  val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
  val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  val isDarkTheme =
    when (themeMode) {
      ThemeMode.LIGHT -> false
      ThemeMode.DARK -> true
      ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: AppDestination.CALCULATOR.route

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(uiState.statusBannerMessage) {
    val msg = uiState.statusBannerMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearBanner()
    }
  }

  // Storage Access Framework (SAF) Launchers — zero broad storage permissions required
  val savePdfLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
      uri?.let { viewModel.writePdfToUri(context, it) }
    }

  val backupJsonLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
      uri?.let { viewModel.exportBackupToUri(context, it) }
    }

  var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
  val restoreJsonLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      uri?.let { pendingRestoreUri = it }
    }

  val exportCsvLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
      uri?.let { viewModel.exportCsvToUri(context, it) }
    }

  AfArifHisabTheme(darkTheme = isDarkTheme) {
    val bgBrush =
      if (isDarkTheme) {
        Brush.verticalGradient(listOf(Color(0xFF071121), Color(0xFF0B1930), Color(0xFF081222)))
      } else {
        Brush.verticalGradient(listOf(Color(0xFFEAF2FF), Color(0xFFF5F9FF), Color(0xFFFFFFFF)))
      }

    fun navigateTo(dest: AppDestination) {
      navController.navigate(dest.route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
      }
    }

    Box(modifier = Modifier.fillMaxSize().background(bgBrush)) {
      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 700.dp

        Scaffold(
          containerColor = Color.Transparent,
          contentWindowInsets = WindowInsets(0, 0, 0, 0),
          snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
          bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
              if (!useRail) {
                NavigationBar(
                  containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                  tonalElevation = 4.dp,
                  windowInsets = WindowInsets(0, 0, 0, 0),
                  modifier = Modifier.height(64.dp),
                ) {
                  AppDestination.entries.forEach { dest ->
                    val selected = currentRoute == dest.route
                    NavigationBarItem(
                      selected = selected,
                      onClick = { navigateTo(dest) },
                      icon = {
                        Icon(
                          imageVector = destinationIcon(dest, selected),
                          contentDescription = dest.labelBengali,
                        )
                      },
                      label = {
                        Text(
                          text = dest.labelBengali,
                          style = MaterialTheme.typography.labelSmall,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis,
                        )
                      },
                      modifier = Modifier.testTag("nav_${dest.route}"),
                    )
                  }
                }
              }
              // Permanent hardcoded Social Media Footer at the very bottom
              PermanentSocialMediaFooter()
            }
          },
        ) { innerPadding ->
          Row(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(innerPadding),
          ) {
            if (useRail) {
              NavigationRail(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                modifier = Modifier.fillMaxHeight(),
              ) {
                AppDestination.entries.forEach { dest ->
                  val selected = currentRoute == dest.route
                  NavigationRailItem(
                    selected = selected,
                    onClick = { navigateTo(dest) },
                    icon = {
                      Icon(
                        imageVector = destinationIcon(dest, selected),
                        contentDescription = dest.labelBengali,
                      )
                    },
                    label = { Text(dest.labelBengali, maxLines = 1) },
                    modifier = Modifier.testTag("rail_${dest.route}"),
                  )
                }
              }
            }

            NavHost(
              navController = navController,
              startDestination = AppDestination.CALCULATOR.route,
              enterTransition = {
                fadeIn(tween(220)) + slideInHorizontally(tween(240)) { it / 14 }
              },
              exitTransition = {
                fadeOut(tween(180)) + slideOutHorizontally(tween(200)) { -it / 16 }
              },
              popEnterTransition = {
                fadeIn(tween(220)) + slideInHorizontally(tween(240)) { -it / 14 }
              },
              popExitTransition = {
                fadeOut(tween(180)) + slideOutHorizontally(tween(200)) { it / 16 }
              },
              modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
              composable(AppDestination.CALCULATOR.route) {
                CalculatorScreen(
                  sheet = sheet,
                  totals = totals,
                  isDarkTheme = isDarkTheme,
                  onMemoNoChange = viewModel::updateMemoNo,
                  onDateChange = viewModel::updateDateMillis,
                  onPartyNameChange = viewModel::updatePartyName,
                  onRowChange = viewModel::updateRow,
                  onClearRow = viewModel::clearRow,
                  onNewSheet = viewModel::startNewSheet,
                  onSaveSheet = viewModel::saveCurrentSheet,
                  onSavePdfDocument = {
                    val dateTag = BengaliFormatters.formatDateIso(sheet.dateMillis)
                    savePdfLauncher.launch("AF-ARIF-Hisab-$dateTag.pdf")
                  },
                  onSharePdf = { viewModel.sharePdf(context, sheet) },
                  onPrintLedger = { viewModel.printLedger(context, sheet) },
                )
              }

              composable(AppDestination.HISTORY.route) {
                HistoryScreen(
                  records = savedRecords,
                  onEditRecord = { rec ->
                    viewModel.loadRecordForEdit(rec) { navigateTo(AppDestination.CALCULATOR) }
                  },
                  onSharePdfRecord = { rec ->
                    viewModel.sharePdf(context, PdfAndPrintManager.sheetFromRecord(rec))
                  },
                  onPrintRecord = { rec ->
                    viewModel.printLedger(context, PdfAndPrintManager.sheetFromRecord(rec))
                  },
                  onDeleteRecord = viewModel::requestDeleteRecord,
                  onGoToCalculator = { navigateTo(AppDestination.CALCULATOR) },
                )
              }

              composable(AppDestination.SEARCH.route) {
                SearchScreen(
                  query = searchQuery,
                  selectedDateMillis = searchDateMillis,
                  results = searchResults,
                  onQueryChange = viewModel::updateSearchQuery,
                  onDateFilterChange = viewModel::updateSearchDateFilter,
                  onEditRecord = { rec ->
                    viewModel.loadRecordForEdit(rec) { navigateTo(AppDestination.CALCULATOR) }
                  },
                  onSharePdfRecord = { rec ->
                    viewModel.sharePdf(context, PdfAndPrintManager.sheetFromRecord(rec))
                  },
                  onPrintRecord = { rec ->
                    viewModel.printLedger(context, PdfAndPrintManager.sheetFromRecord(rec))
                  },
                  onDeleteRecord = viewModel::requestDeleteRecord,
                )
              }

              composable(AppDestination.SETTINGS.route) {
                SettingsScreen(
                  themeMode = themeMode,
                  totalSavedCount = savedRecords.size,
                  onThemeModeChange = viewModel::setThemeMode,
                  onBackupClick = {
                    val dateTag = BengaliFormatters.formatDateIso(System.currentTimeMillis())
                    backupJsonLauncher.launch("AF-ARIF-Backup-$dateTag.json")
                  },
                  onRestoreClick = {
                    restoreJsonLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                  },
                  onExportCsvClick = {
                    val dateTag = BengaliFormatters.formatDateIso(System.currentTimeMillis())
                    exportCsvLauncher.launch("AF-ARIF-Export-$dateTag.csv")
                  },
                  onViewHistoryClick = { navigateTo(AppDestination.HISTORY) },
                  onDeleteAllClick = viewModel::requestDeleteAll,
                )
              }
            }
          }
        }
      }

      // Restore Choice Dialog (Merge or Replace)
      pendingRestoreUri?.let { uri ->
        AlertDialog(
          onDismissRequest = { pendingRestoreUri = null },
          title = { Text("ডেটা রিস্টোর পদ্ধতি") },
          text = {
            Text("আপনি কি পুরোনো হিসাবের সাথে নতুন ব্যাকআপ যুক্ত করবেন, নাকি আগের সব হিসাব প্রতিস্থাপন করবেন?")
          },
          confirmButton = {
            TextButton(
              onClick = {
                pendingRestoreUri = null
                viewModel.restoreBackupFromUri(context, uri, replaceExisting = false)
              },
              modifier = Modifier.testTag("restore_merge_button"),
            ) {
              Text("যুক্ত করুন")
            }
          },
          dismissButton = {
            TextButton(
              onClick = {
                pendingRestoreUri = null
                viewModel.restoreBackupFromUri(context, uri, replaceExisting = true)
              },
              modifier = Modifier.testTag("restore_replace_button"),
            ) {
              Text("সব প্রতিস্থাপন করুন")
            }
          },
        )
      }

      // Animated Save Success Popup
      SaveSuccessPopupDialog(
        visible = uiState.showSaveSuccessPopup,
        title = uiState.saveSuccessTitle,
        subtitle = uiState.saveSuccessSubtitle,
        onDismiss = viewModel::dismissSaveSuccessPopup,
      )

      // Animated Delete Single Record Confirmation
      DeleteConfirmDialog(
        visible = uiState.deleteConfirmRecord != null,
        title = "হিসাব মুছে ফেলবেন?",
        message =
          uiState.deleteConfirmRecord?.let {
            "তারিখ ${it.dateDisplay} (নং: ${it.memoNo}) এর হিসাবটি স্থায়ীভাবে মুছে যাবে।"
          }.orEmpty(),
        onConfirm = viewModel::confirmDeleteRecord,
        onDismiss = viewModel::cancelDeleteRecord,
      )

      // Animated Delete All Confirmation
      DeleteConfirmDialog(
        visible = uiState.showDeleteAllConfirm,
        title = "সকল হিসাব মুছবেন?",
        message = "সংরক্ষিত সব হিসাব স্থায়ীভাবে মুছে যাবে। আগে ব্যাকআপ নিয়ে রাখা ভালো।",
        onConfirm = viewModel::confirmDeleteAll,
        onDismiss = viewModel::cancelDeleteAll,
      )

      // Loading Overlay
      LoadingOverlay(visible = uiState.isLoading, message = uiState.loadingMessage)

      // Animated Welcome Splash Screen
      WelcomeSplashOverlay(
        visible = uiState.showWelcomeScreen,
        onSkip = viewModel::dismissWelcomeImmediately,
      )
    }
  }
}

private fun destinationIcon(dest: AppDestination, selected: Boolean) =
  when (dest) {
    AppDestination.CALCULATOR -> if (selected) Icons.Rounded.Calculate else Icons.Outlined.Calculate
    AppDestination.HISTORY -> if (selected) Icons.Rounded.History else Icons.Outlined.History
    AppDestination.SEARCH -> if (selected) Icons.Rounded.Search else Icons.Outlined.Search
    AppDestination.SETTINGS -> if (selected) Icons.Rounded.Settings else Icons.Outlined.Settings
  }
