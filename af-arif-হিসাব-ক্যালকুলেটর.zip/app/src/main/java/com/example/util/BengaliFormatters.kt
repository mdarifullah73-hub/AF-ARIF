package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BengaliFormatters {
  private val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

  private val bengaliMonths =
    arrayOf(
      "জানুয়ারি",
      "ফেব্রুয়ারি",
      "মার্চ",
      "এপ্রিল",
      "মে",
      "জুন",
      "জুলাই",
      "আগস্ট",
      "সেপ্টেম্বর",
      "অক্টোবর",
      "নভেম্বর",
      "ডিসেম্বর",
    )

  fun toBengaliDigits(value: Int): String = toBengaliDigits(value.toString())

  fun toBengaliDigits(value: Long): String = toBengaliDigits(value.toString())

  fun toBengaliDigits(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
      if (ch in '0'..'9') {
        sb.append(bengaliDigits[ch - '0'])
      } else {
        sb.append(ch)
      }
    }
    return sb.toString()
  }

  fun toEnglishDigits(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
      val idx = bengaliDigits.indexOf(ch)
      if (idx >= 0) {
        sb.append(('0'.code + idx).toChar())
      } else {
        sb.append(ch)
      }
    }
    return sb.toString()
  }

  /**
   * Keeps only digits (both Bengali and English) for clean numeric entry.
   */
  fun filterNumericInput(input: String): String {
    val sb = StringBuilder()
    for (ch in input) {
      if (ch in '0'..'9' || ch in bengaliDigits) {
        sb.append(ch)
      }
    }
    return sb.toString()
  }

  fun parseNonNegativeLong(input: String): Long {
    val cleaned = toEnglishDigits(input.trim()).filter { it in '0'..'9' }
    if (cleaned.isEmpty()) return 0L
    return cleaned.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
  }

  fun formatSerial(serial: Int): String {
    val padded = serial.toString().padStart(2, '0')
    return toBengaliDigits(padded)
  }

  fun formatDateDisplay(millis: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
    return toBengaliDigits(sdf.format(Date(millis)))
  }

  fun formatDateLongBengali(millis: Long): String {
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = millis }
    val day = toBengaliDigits(cal.get(java.util.Calendar.DAY_OF_MONTH).toString().padStart(2, '0'))
    val month = bengaliMonths[cal.get(java.util.Calendar.MONTH)]
    val year = toBengaliDigits(cal.get(java.util.Calendar.YEAR))
    return "$day $month $year"
  }

  fun formatDateIso(millis: Long): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(Date(millis))
  }

  fun formatCombinedWeight(finalKg: Long, remainingGram: Long): String {
    return "${toBengaliDigits(finalKg)} কেজি ${toBengaliDigits(remainingGram)} গ্রাম"
  }

  fun formatDecimalKg(finalKg: Long, remainingGram: Long): String {
    val gramPadded = remainingGram.toString().padStart(3, '0')
    return "${toBengaliDigits(finalKg)}.${toBengaliDigits(gramPadded)} কেজি"
  }
}
