package com.example.data

import com.example.data.local.LedgerDao
import com.example.data.local.LedgerRecordEntity
import com.example.util.BengaliFormatters
import kotlinx.coroutines.flow.Flow

class LedgerRepository(private val ledgerDao: LedgerDao) {
  val allRecords: Flow<List<LedgerRecordEntity>> = ledgerDao.observeAllRecords()

  fun searchRecords(query: String): Flow<List<LedgerRecordEntity>> {
    val trimmed = query.trim()
    if (trimmed.isEmpty()) return allRecords
    // Also search by Bengali-digit variant if user typed English digits (e.g. 23/11/2026)
    val bengaliVariant = BengaliFormatters.toBengaliDigits(trimmed)
    return if (bengaliVariant != trimmed) {
      ledgerDao.searchRecords(bengaliVariant)
    } else {
      ledgerDao.searchRecords(trimmed)
    }
  }

  suspend fun saveSheet(sheet: ActiveLedgerSheet): Long {
    val normalizedRows = LedgerJsonCodec.normalizeFortyRows(sheet.rows)
    val totals = calculateLedgerTotals(normalizedRows)
    val shopNames =
      normalizedRows
        .mapNotNull { it.shopName.trim().takeIf { s -> s.isNotEmpty() } }
        .distinct()
        .joinToString(", ")
    val now = System.currentTimeMillis()
    val dateDisplay = BengaliFormatters.formatDateDisplay(sheet.dateMillis)
    val dateIso = BengaliFormatters.formatDateIso(sheet.dateMillis)
    val memoDisplay =
      sheet.memoNo.trim().ifBlank { BengaliFormatters.formatSerial((ledgerDao.getRecordCount() + 1).coerceAtMost(999)) }

    val existingId = sheet.editingRecordId
    return if (existingId != null) {
      val existing = ledgerDao.getRecordById(existingId)
      val entity =
        LedgerRecordEntity(
          id = existingId,
          memoNo = memoDisplay,
          dateMillis = sheet.dateMillis,
          dateDisplay = dateDisplay,
          dateIso = dateIso,
          partyName = sheet.partyName.trim(),
          shopNamesIndex = shopNames,
          rowsJson = LedgerJsonCodec.encodeRows(normalizedRows),
          totalPieces = totals.totalPieces,
          finalKg = totals.finalKg,
          remainingGram = totals.remainingGram,
          createdAt = existing?.createdAt ?: now,
          updatedAt = now,
        )
      ledgerDao.updateRecord(entity)
      existingId
    } else {
      val entity =
        LedgerRecordEntity(
          memoNo = memoDisplay,
          dateMillis = sheet.dateMillis,
          dateDisplay = dateDisplay,
          dateIso = dateIso,
          partyName = sheet.partyName.trim(),
          shopNamesIndex = shopNames,
          rowsJson = LedgerJsonCodec.encodeRows(normalizedRows),
          totalPieces = totals.totalPieces,
          finalKg = totals.finalKg,
          remainingGram = totals.remainingGram,
          createdAt = now,
          updatedAt = now,
        )
      ledgerDao.insertRecord(entity)
    }
  }

  suspend fun getRecordById(id: Long): LedgerRecordEntity? = ledgerDao.getRecordById(id)

  suspend fun getAllSnapshot(): List<LedgerRecordEntity> = ledgerDao.getAllRecordsSnapshot()

  suspend fun restoreBackupRecords(records: List<LedgerRecordEntity>, replaceExisting: Boolean) {
    if (replaceExisting) {
      ledgerDao.deleteAll()
    }
    ledgerDao.insertAll(records)
  }

  suspend fun deleteRecord(id: Long) = ledgerDao.deleteById(id)

  suspend fun deleteAll() = ledgerDao.deleteAll()
}
