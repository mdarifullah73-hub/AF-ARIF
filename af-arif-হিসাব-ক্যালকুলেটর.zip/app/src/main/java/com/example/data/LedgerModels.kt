package com.example.data

import com.example.data.local.LedgerRecordEntity
import com.example.util.BengaliFormatters
import org.json.JSONArray
import org.json.JSONObject

const val TOTAL_LEDGER_ROWS = 40

enum class ThemeMode(val labelBengali: String) {
  SYSTEM("সিস্টেম ডিফল্ট"),
  LIGHT("লাইট মোড"),
  DARK("ডার্ক মোড"),
}

data class LedgerRow(
  val serial: Int,
  val pieces: String = "",
  val kg: String = "",
  val gram: String = "",
  val shopName: String = "",
) {
  val isEmpty: Boolean
    get() = pieces.isBlank() && kg.isBlank() && gram.isBlank() && shopName.isBlank()
}

data class LedgerTotals(
  val totalPieces: Long = 0L,
  val rawTotalKg: Long = 0L,
  val rawTotalGram: Long = 0L,
  val finalKg: Long = 0L,
  val remainingGram: Long = 0L,
  val combinedWeightText: String = "০ কেজি ০ গ্রাম",
  val decimalWeightText: String = "০.০০০ কেজি",
  val filledRowCount: Int = 0,
)

data class ActiveLedgerSheet(
  val editingRecordId: Long? = null,
  val memoNo: String = "০১",
  val dateMillis: Long = System.currentTimeMillis(),
  val partyName: String = "",
  val rows: List<LedgerRow> = defaultFortyRows(),
)

fun defaultFortyRows(): List<LedgerRow> = (1..TOTAL_LEDGER_ROWS).map { LedgerRow(serial = it) }

fun calculateLedgerTotals(rows: List<LedgerRow>): LedgerTotals {
  var totalPieces = 0L
  var rawTotalKg = 0L
  var rawTotalGram = 0L
  var filledCount = 0

  for (row in rows) {
    val p = BengaliFormatters.parseNonNegativeLong(row.pieces)
    val k = BengaliFormatters.parseNonNegativeLong(row.kg)
    val g = BengaliFormatters.parseNonNegativeLong(row.gram)
    totalPieces += p
    rawTotalKg += k
    rawTotalGram += g
    if (!row.isEmpty) filledCount++
  }

  val extraKg = rawTotalGram / 1000L
  val finalKg = rawTotalKg + extraKg
  val remainingGram = rawTotalGram % 1000L

  return LedgerTotals(
    totalPieces = totalPieces,
    rawTotalKg = rawTotalKg,
    rawTotalGram = rawTotalGram,
    finalKg = finalKg,
    remainingGram = remainingGram,
    combinedWeightText = BengaliFormatters.formatCombinedWeight(finalKg, remainingGram),
    decimalWeightText = BengaliFormatters.formatDecimalKg(finalKg, remainingGram),
    filledRowCount = filledCount,
  )
}

object LedgerJsonCodec {
  fun encodeRows(rows: List<LedgerRow>): String {
    val arr = JSONArray()
    val normalized = normalizeFortyRows(rows)
    for (row in normalized) {
      val obj =
        JSONObject().apply {
          put("serial", row.serial)
          put("pieces", row.pieces)
          put("kg", row.kg)
          put("gram", row.gram)
          put("shopName", row.shopName)
        }
      arr.put(obj)
    }
    return arr.toString()
  }

  fun decodeRows(json: String): List<LedgerRow> {
    val base = defaultFortyRows().toMutableList()
    try {
      val arr = JSONArray(json)
      for (i in 0 until arr.length()) {
        val obj = arr.optJSONObject(i) ?: continue
        val serial = obj.optInt("serial", i + 1)
        if (serial in 1..TOTAL_LEDGER_ROWS) {
          base[serial - 1] =
            LedgerRow(
              serial = serial,
              pieces = obj.optString("pieces", ""),
              kg = obj.optString("kg", ""),
              gram = obj.optString("gram", ""),
              shopName = obj.optString("shopName", ""),
            )
        }
      }
    } catch (_: Exception) {
      // Fall back to empty 40 rows on malformed JSON
    }
    return base
  }

  fun normalizeFortyRows(rows: List<LedgerRow>): List<LedgerRow> {
    val map = rows.associateBy { it.serial }
    return (1..TOTAL_LEDGER_ROWS).map { idx -> map[idx] ?: LedgerRow(serial = idx) }
  }

  fun encodeDraft(sheet: ActiveLedgerSheet): String {
    return JSONObject()
      .apply {
        put("editingRecordId", sheet.editingRecordId ?: -1L)
        put("memoNo", sheet.memoNo)
        put("dateMillis", sheet.dateMillis)
        put("partyName", sheet.partyName)
        put("rows", JSONArray(encodeRows(sheet.rows)))
      }
      .toString()
  }

  fun decodeDraft(json: String): ActiveLedgerSheet? {
    if (json.isBlank()) return null
    return try {
      val obj = JSONObject(json)
      val editId = obj.optLong("editingRecordId", -1L).let { if (it > 0L) it else null }
      val memoNo = obj.optString("memoNo", "০১")
      val dateMillis = obj.optLong("dateMillis", System.currentTimeMillis())
      val partyName = obj.optString("partyName", "")
      val rowsArr = obj.optJSONArray("rows")?.toString() ?: "[]"
      ActiveLedgerSheet(
        editingRecordId = editId,
        memoNo = memoNo,
        dateMillis = dateMillis,
        partyName = partyName,
        rows = decodeRows(rowsArr),
      )
    } catch (_: Exception) {
      null
    }
  }

  fun encodeBackup(records: List<LedgerRecordEntity>): String {
    val arr = JSONArray()
    for (rec in records) {
      val obj =
        JSONObject().apply {
          put("id", rec.id)
          put("memoNo", rec.memoNo)
          put("dateMillis", rec.dateMillis)
          put("dateDisplay", rec.dateDisplay)
          put("dateIso", rec.dateIso)
          put("partyName", rec.partyName)
          put("shopNamesIndex", rec.shopNamesIndex)
          put("rowsJson", rec.rowsJson)
          put("totalPieces", rec.totalPieces)
          put("finalKg", rec.finalKg)
          put("remainingGram", rec.remainingGram)
          put("createdAt", rec.createdAt)
          put("updatedAt", rec.updatedAt)
        }
      arr.put(obj)
    }
    return JSONObject()
      .apply {
        put("app", "AF-ARIF হিসাব ক্যালকুলেটর")
        put("version", 1)
        put("exportedAt", System.currentTimeMillis())
        put("recordCount", records.size)
        put("records", arr)
      }
      .toString(2)
  }

  fun decodeBackup(json: String): Result<List<LedgerRecordEntity>> {
    return try {
      val root = JSONObject(json)
      val arr = root.getJSONArray("records")
      val list = mutableListOf<LedgerRecordEntity>()
      for (i in 0 until arr.length()) {
        val obj = arr.getJSONObject(i)
        val rowsJson = obj.optString("rowsJson", "[]")
        val rows = decodeRows(rowsJson)
        val totals = calculateLedgerTotals(rows)
        val dateMillis = obj.optLong("dateMillis", System.currentTimeMillis())
        val shopNames =
          rows.mapNotNull { it.shopName.trim().takeIf { name -> name.isNotEmpty() } }.distinct().joinToString(", ")
        list.add(
          LedgerRecordEntity(
            id = 0L, // Let Room auto-generate on restore to prevent ID collisions
            memoNo = obj.optString("memoNo", "০১"),
            dateMillis = dateMillis,
            dateDisplay = obj.optString("dateDisplay").ifBlank { BengaliFormatters.formatDateDisplay(dateMillis) },
            dateIso = obj.optString("dateIso").ifBlank { BengaliFormatters.formatDateIso(dateMillis) },
            partyName = obj.optString("partyName", ""),
            shopNamesIndex = obj.optString("shopNamesIndex").ifBlank { shopNames },
            rowsJson = encodeRows(rows),
            totalPieces = obj.optLong("totalPieces", totals.totalPieces),
            finalKg = obj.optLong("finalKg", totals.finalKg),
            remainingGram = obj.optLong("remainingGram", totals.remainingGram),
            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
          )
        )
      }
      Result.success(list)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun encodeRecordsToCsv(records: List<LedgerRecordEntity>): String {
    val sb = StringBuilder()
    sb.append("\uFEFF") // UTF-8 BOM for Excel / mobile spreadsheet Bengali support
    sb.append("নং,তারিখ,নাম,ক্রমিক,পিস,কেজি,গ্রাম,দোকানের নাম,সর্বমোট পিস,সর্বমোট কেজি,সর্বমোট গ্রাম\n")
    for (rec in records) {
      val rows = decodeRows(rec.rowsJson)
      val nonEmpty = rows.filter { !it.isEmpty }.ifEmpty { listOf(LedgerRow(1)) }
      for (row in nonEmpty) {
        val cells =
          listOf(
            rec.memoNo,
            rec.dateDisplay,
            rec.partyName,
            BengaliFormatters.formatSerial(row.serial),
            row.pieces.ifBlank { "0" },
            row.kg.ifBlank { "0" },
            row.gram.ifBlank { "0" },
            row.shopName,
            rec.totalPieces.toString(),
            rec.finalKg.toString(),
            rec.remainingGram.toString(),
          )
        sb.append(cells.joinToString(",") { escapeCsv(it) }).append("\n")
      }
    }
    return sb.toString()
  }

  private fun escapeCsv(value: String): String {
    val escaped = value.replace("\"", "\"\"")
    return "\"$escaped\""
  }
}
