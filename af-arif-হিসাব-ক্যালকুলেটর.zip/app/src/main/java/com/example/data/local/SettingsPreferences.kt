package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.ActiveLedgerSheet
import com.example.data.LedgerJsonCodec
import com.example.data.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "af_arif_settings")

class SettingsPreferences(private val context: Context) {
  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val DRAFT_JSON = stringPreferencesKey("active_draft_json")
  }

  val themeModeFlow: Flow<ThemeMode> =
    context.dataStore.data.map { prefs ->
      val raw = prefs[Keys.THEME_MODE] ?: ThemeMode.LIGHT.name
      runCatching { ThemeMode.valueOf(raw) }.getOrDefault(ThemeMode.LIGHT)
    }

  val draftSheetFlow: Flow<ActiveLedgerSheet?> =
    context.dataStore.data.map { prefs ->
      val raw = prefs[Keys.DRAFT_JSON].orEmpty()
      LedgerJsonCodec.decodeDraft(raw)
    }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.dataStore.edit { prefs -> prefs[Keys.THEME_MODE] = mode.name }
  }

  suspend fun saveDraft(sheet: ActiveLedgerSheet) {
    val json = LedgerJsonCodec.encodeDraft(sheet)
    context.dataStore.edit { prefs -> prefs[Keys.DRAFT_JSON] = json }
  }

  suspend fun clearDraft() {
    context.dataStore.edit { prefs -> prefs.remove(Keys.DRAFT_JSON) }
  }
}
