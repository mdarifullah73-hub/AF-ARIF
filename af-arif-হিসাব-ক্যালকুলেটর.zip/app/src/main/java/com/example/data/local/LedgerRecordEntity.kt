package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ledger_records")
data class LedgerRecordEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val memoNo: String,
  val dateMillis: Long,
  val dateDisplay: String,
  val dateIso: String,
  val partyName: String,
  val shopNamesIndex: String,
  val rowsJson: String,
  val totalPieces: Long,
  val finalKg: Long,
  val remainingGram: Long,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
)
