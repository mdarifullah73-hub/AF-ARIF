package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LedgerDao {
  @Query("SELECT * FROM ledger_records ORDER BY dateMillis DESC, updatedAt DESC")
  fun observeAllRecords(): Flow<List<LedgerRecordEntity>>

  @Query(
    """
    SELECT * FROM ledger_records
    WHERE dateDisplay LIKE '%' || :query || '%'
       OR dateIso LIKE '%' || :query || '%'
       OR shopNamesIndex LIKE '%' || :query || '%'
       OR partyName LIKE '%' || :query || '%'
       OR memoNo LIKE '%' || :query || '%'
    ORDER BY dateMillis DESC, updatedAt DESC
    """
  )
  fun searchRecords(query: String): Flow<List<LedgerRecordEntity>>

  @Query("SELECT * FROM ledger_records WHERE id = :id LIMIT 1")
  suspend fun getRecordById(id: Long): LedgerRecordEntity?

  @Query("SELECT * FROM ledger_records ORDER BY dateMillis DESC, updatedAt DESC")
  suspend fun getAllRecordsSnapshot(): List<LedgerRecordEntity>

  @Query("SELECT COUNT(*) FROM ledger_records")
  suspend fun getRecordCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRecord(record: LedgerRecordEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(records: List<LedgerRecordEntity>)

  @Update
  suspend fun updateRecord(record: LedgerRecordEntity)

  @Query("DELETE FROM ledger_records WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM ledger_records")
  suspend fun deleteAll()
}
