package com.example.data

/**
 * Permanent, immutable social media links hardcoded into source code.
 * Cannot be edited, removed, or overridden from any settings or admin screen.
 */
object SocialLinks {
  const val TIKTOK_URL = "https://www.tiktok.com/@a.f.arif4.0"
  const val TELEGRAM_URL = "https://t.me/Premium_apk782"
  const val FACEBOOK_URL = "https://www.facebook.com/share/1JrJASgJxJ/"
}
