package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.ActiveLedgerSheet
import com.example.data.LedgerJsonCodec
import com.example.data.LedgerRow
import com.example.data.TOTAL_LEDGER_ROWS
import com.example.data.calculateLedgerTotals
import com.example.data.local.LedgerRecordEntity
import com.example.util.BengaliFormatters
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object PdfAndPrintManager {
  private const val PAGE_WIDTH = 595
  private const val PAGE_HEIGHT = 842

  fun sheetFromRecord(record: LedgerRecordEntity): ActiveLedgerSheet {
    return ActiveLedgerSheet(
      editingRecordId = record.id,
      memoNo = record.memoNo,
      dateMillis = record.dateMillis,
      partyName = record.partyName,
      rows = LedgerJsonCodec.decodeRows(record.rowsJson),
    )
  }

  fun buildPdfDocument(context: Context, sheet: ActiveLedgerSheet): PdfDocument {
    val pdfDocument = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    drawLedgerPage(context, page.canvas, sheet)
    pdfDocument.finishPage(page)
    return pdfDocument
  }

  fun writePdfToOutputStream(context: Context, sheet: ActiveLedgerSheet, out: OutputStream) {
    val doc = buildPdfDocument(context, sheet)
    try {
      doc.writeTo(out)
    } finally {
      doc.close()
    }
  }

  fun writePdfToUri(context: Context, uri: Uri, sheet: ActiveLedgerSheet): Result<Unit> {
    return runCatching {
      context.contentResolver.openOutputStream(uri)?.use { out ->
        writePdfToOutputStream(context, sheet, out)
      } ?: error("ফাইল আউটপুট খোলা যায়নি")
    }
  }

  fun createTempPdfAndShare(context: Context, sheet: ActiveLedgerSheet): Result<Intent> {
    return runCatching {
      val dir = File(context.cacheDir, "exports").apply { mkdirs() }
      val dateTag = BengaliFormatters.formatDateIso(sheet.dateMillis)
      val file = File(dir, "AF-ARIF-Hisab-$dateTag.pdf")
      FileOutputStream(file).use { out -> writePdfToOutputStream(context, sheet, out) }
      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "AF-ARIF হিসাব ক্যালকুলেটর - ${BengaliFormatters.formatDateDisplay(sheet.dateMillis)}")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    }
  }

  fun createTempCsvAndShare(context: Context, csvContent: String): Result<Intent> {
    return runCatching {
      val dir = File(context.cacheDir, "exports").apply { mkdirs() }
      val file = File(dir, "AF-ARIF-All-Hisab.csv")
      file.writeText(csvContent, Charsets.UTF_8)
      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "AF-ARIF সকল হিসাব এক্সপোর্ট")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    }
  }

  fun printLedger(context: Context, sheet: ActiveLedgerSheet) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
    val jobName = "AF-ARIF হিসাব - ${BengaliFormatters.formatDateDisplay(sheet.dateMillis)}"
    val adapter =
      object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?,
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info =
            PrintDocumentInfo.Builder("af_arif_hisab.pdf")
              .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
              .setPageCount(1)
              .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?,
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onWriteCancelled()
            return
          }
          if (destination == null) {
            callback?.onWriteFailed("ফাইল পাওয়া যায়নি")
            return
          }
          try {
            FileOutputStream(destination.fileDescriptor).use { out ->
              writePdfToOutputStream(context, sheet, out)
            }
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }
      }
    printManager.print(
      jobName,
      adapter,
      PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build(),
    )
  }

  private fun drawLedgerPage(context: Context, canvas: Canvas, sheet: ActiveLedgerSheet) {
    val baseTypeface =
      ResourcesCompat.getFont(context, R.font.hind_siliguri) ?: Typeface.DEFAULT
    val boldTypeface = Typeface.create(baseTypeface, Typeface.BOLD)

    val left = 26f
    val right = 569f
    val tableWidth = right - left

    // Background white
    canvas.drawColor(Color.WHITE)

    // 1. Brand Header Bar
    val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0D47A1") }
    canvas.drawRoundRect(RectF(left, 20f, right, 54f), 6f, 6f, headerPaint)

    val brandPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 14f
        typeface = boldTypeface
      }
    canvas.drawText("AF-ARIF হিসাব ক্যালকুলেটর", left + 12f, 42f, brandPaint)

    val subBrandPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#DCEBFF")
        textSize = 9.5f
        typeface = baseTypeface
        textAlign = Paint.Align.RIGHT
      }
    canvas.drawText("অটোমেটিক ডিজিটাল হিসাব খাতা (৪০ সারি)", right - 12f, 41f, subBrandPaint)

    // 2. Memo Info (নং, তারিখ, নাম)
    val metaPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B1F3A")
        textSize = 10.5f
        typeface = boldTypeface
      }
    val dateDisplay = BengaliFormatters.formatDateDisplay(sheet.dateMillis)
    val memoText = "নং: ${sheet.memoNo.ifBlank { "০১" }}"
    val dateText = "তারিখ: $dateDisplay"
    val partyText = "নাম: ${sheet.partyName.ifBlank { "................................................................" }}"

    canvas.drawText(memoText, left + 4f, 70f, metaPaint)
    val rightMetaPaint = Paint(metaPaint).apply { textAlign = Paint.Align.RIGHT }
    canvas.drawText(dateText, right - 4f, 70f, rightMetaPaint)
    canvas.drawText(partyText, left + 4f, 88f, metaPaint)

    // 3. Table Column Geometry (Matching Reference Photo)
    val colSerialEnd = left + 46f
    val colPiecesEnd = colSerialEnd + 66f
    val colKgEnd = colPiecesEnd + 66f
    val colGramEnd = colKgEnd + 66f
    val colShopEnd = right

    val tableTop = 98f
    val headerHeight = 22f
    val rowHeight = 15.4f

    // Table Header
    val tableHeaderBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#103F91") }
    canvas.drawRect(left, tableTop, right, tableTop + headerHeight, tableHeaderBg)

    val thTextPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10f
        typeface = boldTypeface
        textAlign = Paint.Align.CENTER
      }
    val thY = tableTop + 15f
    canvas.drawText("ক্রমিক", (left + colSerialEnd) / 2f, thY, thTextPaint)
    canvas.drawText("পিস", (colSerialEnd + colPiecesEnd) / 2f, thY, thTextPaint)
    canvas.drawText("কেজি", (colPiecesEnd + colKgEnd) / 2f, thY, thTextPaint)
    canvas.drawText("গ্রাম", (colKgEnd + colGramEnd) / 2f, thY, thTextPaint)
    canvas.drawText("দোকানের নাম", (colGramEnd + colShopEnd) / 2f, thY, thTextPaint)

    // 40 Rows
    val rows = LedgerJsonCodec.normalizeFortyRows(sheet.rows)
    val stripePaint = Paint().apply { color = Color.parseColor("#F5F9FF") }
    val borderPaint =
      Paint().apply {
        color = Color.parseColor("#8CA6CC")
        strokeWidth = 0.7f
        style = Paint.Style.STROKE
      }
    val cellCenterPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B1F3A")
        textSize = 9.2f
        typeface = baseTypeface
        textAlign = Paint.Align.CENTER
      }
    val cellShopPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B1F3A")
        textSize = 9.2f
        typeface = baseTypeface
        textAlign = Paint.Align.LEFT
      }
    val serialPaint =
      Paint(cellCenterPaint).apply {
        typeface = boldTypeface
        color = Color.parseColor("#0D47A1")
      }

    var currentTop = tableTop + headerHeight
    for (i in 0 until TOTAL_LEDGER_ROWS) {
      val row: LedgerRow = rows[i]
      val rowBottom = currentTop + rowHeight
      if (i % 2 == 1) {
        canvas.drawRect(left, currentTop, right, rowBottom, stripePaint)
      }
      val textY = currentTop + 11.4f
      canvas.drawText(BengaliFormatters.formatSerial(row.serial), (left + colSerialEnd) / 2f, textY, serialPaint)
      if (row.pieces.isNotBlank()) {
        canvas.drawText(BengaliFormatters.toBengaliDigits(row.pieces), (colSerialEnd + colPiecesEnd) / 2f, textY, cellCenterPaint)
      }
      if (row.kg.isNotBlank()) {
        canvas.drawText(BengaliFormatters.toBengaliDigits(row.kg), (colPiecesEnd + colKgEnd) / 2f, textY, cellCenterPaint)
      }
      if (row.gram.isNotBlank()) {
        canvas.drawText(BengaliFormatters.toBengaliDigits(row.gram), (colKgEnd + colGramEnd) / 2f, textY, cellCenterPaint)
      }
      if (row.shopName.isNotBlank()) {
        val clippedShop = ellipsizeText(row.shopName.trim(), cellShopPaint, (colShopEnd - colGramEnd) - 12f)
        canvas.drawText(clippedShop, colGramEnd + 6f, textY, cellShopPaint)
      }
      canvas.drawLine(left, rowBottom, right, rowBottom, borderPaint)
      currentTop = rowBottom
    }

    val tableBottom = currentTop
    // Vertical grid lines
    canvas.drawRect(left, tableTop, right, tableBottom, borderPaint)
    val colLines = listOf(colSerialEnd, colPiecesEnd, colKgEnd, colGramEnd)
    for (x in colLines) {
      canvas.drawLine(x, tableTop, x, tableBottom, borderPaint)
    }

    // 4. Totals Summary Footer
    val totals = calculateLedgerTotals(rows)
    val summaryTop = tableBottom + 10f
    val summaryBottom = summaryTop + 56f
    val summaryBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EEF5FF") }
    val summaryBorder =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0D47A1")
        strokeWidth = 1.1f
        style = Paint.Style.STROKE
      }
    canvas.drawRoundRect(RectF(left, summaryTop, right, summaryBottom), 6f, 6f, summaryBg)
    canvas.drawRoundRect(RectF(left, summaryTop, right, summaryBottom), 6f, 6f, summaryBorder)

    val sumLabelPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0D47A1")
        textSize = 9.5f
        typeface = boldTypeface
      }
    val sumValuePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B1F3A")
        textSize = 11.5f
        typeface = boldTypeface
      }

    val thirdWidth = tableWidth / 3f
    // Card 1: Total Pieces
    canvas.drawText("সর্বমোট পিস", left + 12f, summaryTop + 18f, sumLabelPaint)
    canvas.drawText("${BengaliFormatters.toBengaliDigits(totals.totalPieces)} পিস", left + 12f, summaryTop + 38f, sumValuePaint)

    // Divider 1
    canvas.drawLine(left + thirdWidth, summaryTop + 8f, left + thirdWidth, summaryBottom - 8f, borderPaint)

    // Card 2: Total Kg
    canvas.drawText("সর্বমোট কেজি", left + thirdWidth + 12f, summaryTop + 18f, sumLabelPaint)
    canvas.drawText("${BengaliFormatters.toBengaliDigits(totals.finalKg)} কেজি", left + thirdWidth + 12f, summaryTop + 38f, sumValuePaint)

    // Divider 2
    canvas.drawLine(left + thirdWidth * 2f, summaryTop + 8f, left + thirdWidth * 2f, summaryBottom - 8f, borderPaint)

    // Card 3: Remaining Gram + Combined Weight
    canvas.drawText("অবশিষ্ট গ্রাম ও সম্মিলিত ওজন", left + thirdWidth * 2f + 12f, summaryTop + 18f, sumLabelPaint)
    canvas.drawText(totals.combinedWeightText, left + thirdWidth * 2f + 12f, summaryTop + 38f, sumValuePaint)

    // Tiny Footer Credit
    val footerPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5C7394")
        textSize = 8f
        typeface = baseTypeface
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("AF-ARIF হিসাব ক্যালকুলেটর • অফলাইন ডিজিটাল হিসাব বিবরণী", (left + right) / 2f, 828f, footerPaint)
  }

  private fun ellipsizeText(text: String, paint: Paint, maxWidth: Float): String {
    if (paint.measureText(text) <= maxWidth) return text
    var end = text.length
    while (end > 1 && paint.measureText(text.substring(0, end) + "…") > maxWidth) {
      end--
    }
    return text.substring(0, end) + "…"
  }
}
